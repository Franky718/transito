import { createFileRoute } from "@tanstack/react-router";
import { Component, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";
import { CSS, LOGO } from "@/lib/ui";
import MapaReportes from "@/components/mapa-reportes";
import { Reglamento } from "@/components/app-extras";
import { Accidentes, Bitacora, Inicio, Oficiales, Operativos } from "@/components/personal-tabs";
import { Antecedentes, BusquedaIA, Checador, Corralon, Evaluaciones, Flotilla, SosActivas, SosBoton } from "@/components/operativo-tabs";
import MapaCalor from "@/components/mapa-calor";
import { DepartamentosEditor, Licenciamiento, PlanesEditor, ReglamentoEditor, TipoCambio } from "@/components/editor-tabs";

export const Route = createFileRoute("/admin")({ component: Admin });

const ESTATUS = ["Recibido", "En atención", "Atendido", "Rechazado"];
const TIPOS_PLACA = ["Particular", "Servicio público", "Carga", "Motocicleta", "Extranjera"];
const mxn = (n: number) => "$" + n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type Yo = { id: string; nombre: string; rol: "admin" | "oficial" };

function Panel({ clave, salir, yo }: { clave: string; salir: () => void; yo: Yo }) {
  const [vista, setVista] = useState("ini");
  const [msg, setMsg] = useState("");
  // multa
  const [causo, setCauso] = useState(false);
  const [placa, setPlaca] = useState("");
  const [tipoPlaca, setTipoPlaca] = useState(TIPOS_PLACA[0]);
  const [infId, setInfId] = useState("");
  const [obs, setObs] = useState("");
  // catálogo
  const [cInf, setCInf] = useState("");
  const [cDesc, setCDesc] = useState("");
  const [cMin, setCMin] = useState("");
  const [cMax, setCMax] = useState("");
  const [umaNueva, setUmaNueva] = useState("");

  const reportes = useQuery(api.reportes.listarAdmin, { clave });
  const multas = useQuery(api.multas.listarAdmin, { clave });
  const infs = useQuery(api.infracciones.listar);
  const uma = useQuery(api.infracciones.valorUma);
  const cambiar = useMutation(api.reportes.cambiarEstatus);
  const registrar = useMutation(api.multas.registrar);
  const pagar = useMutation(api.multas.marcarPagada);
  const addInf = useMutation(api.infracciones.agregar);
  const fijarUma = useMutation(api.infracciones.fijarUma);
  const sembrar = useMutation(api.infracciones.sembrar);
  const verifPartida = useMutation(api.infracciones.verificarPartida);
  const actualizarInf = useMutation(api.infracciones.actualizar);
  const borrarInf = useMutation(api.infracciones.borrar);
  const [editId, setEditId] = useState<Id<"infracciones"> | null>(null);

  const sel = infs?.find((i) => i._id === infId);

  const alta = async () => {
    if (!sel) return setMsg("Elige una infracción del catálogo.");
    try {
      const r = await registrar({ clave, placa, tipoPlaca, infraccionId: sel._id as Id<"infracciones">, observaciones: obs || undefined, causoAccidente: causo });
      setMsg(`Multa ${r.folio}: ${r.monto_umas} UMA = ${mxn(r.monto_mxn)}`);
      setPlaca("");
      setObs("");
    } catch {
      setMsg("Revisa placa e infracción (debe estar verificada).");
    }
  };

  const altaInf = async () => {
    try {
      if (editId) {
        await actualizarInf({ clave, id: editId, clave_inf: cInf, descripcion: cDesc, umasMin: Number(cMin), umasMax: Number(cMax) });
        setEditId(null);
        setMsg("Infracción actualizada y verificada.");
      } else {
        await addInf({ clave, clave_inf: cInf, descripcion: cDesc, umasMin: Number(cMin), umasMax: Number(cMax) });
        setMsg("Infracción agregada al catálogo.");
      }
      setCInf(""); setCDesc(""); setCMin(""); setCMax("");
    } catch {
      setMsg("Revisa descripción y UMAs (máximo ≥ mínimo).");
    }
  };

  return (
    <>
      <SosActivas clave={clave} />
      <p className="note" style={{ marginTop: 0 }}>Sesión: <b>{yo.nombre}</b> · {yo.id} · {yo.rol === "admin" ? "Administración" : "Oficial"}</p>
      <div className="row" style={{ border: 0, padding: 0, marginBottom: 10 }}>
        <select value={vista} onChange={(e) => { setVista(e.target.value); setMsg(""); }} style={{ marginBottom: 0 }}>
          <optgroup label="Operación">
            <option value="ini">Inicio</option>
            <option value="rep">Reportes ciudadanos</option>
            <option value="map">Mapa de reportes</option>
            <option value="cal">Mapa de calor</option>
            <option value="ant">Consulta de antecedentes</option>
            <option value="acc">Accidentes</option>
            <option value="cor">Corralón y grúas</option>
            <option value="ope">Operativos</option>
            <option value="mul">Multas</option>
          </optgroup>
          <optgroup label="Personal y unidades">
            <option value="che">Checador digital</option>
            <option value="bit">Bitácora de turno</option>
            <option value="flo">Flotilla</option>
            <option value="eva">Buzón de transparencia</option>
          </optgroup>
          <optgroup label="Consulta">
            <option value="reg">Reglamento</option>
            <option value="ia">Búsqueda inteligente (IA)</option>
          </optgroup>
          {yo.rol === "admin" && (
            <optgroup label="Administración">
              <option value="edi">Editar reglamento (ciudadanía)</option>
              <option value="cat">Tabulador / UMA / dólar</option>
              <option value="dep">Direcciones de la Secretaría</option>
              <option value="pla">Planes comerciales</option>
              <option value="lic">Licenciamiento y pagos</option>
              <option value="ofi">Oficiales y claves</option>
            </optgroup>
          )}
        </select>
        <button className="btn sm" style={{ marginBottom: 0 }} onClick={salir}>Salir</button>
      </div>
      <SosBoton clave={clave} />
      {vista === "ini" && <Inicio clave={clave} />}
      {vista === "ofi" && yo.rol === "admin" && <Oficiales clave={clave} />}
      {vista === "cal" && <MapaCalor clave={clave} />}
      {vista === "ant" && <Antecedentes clave={clave} />}
      {vista === "cor" && <Corralon clave={clave} />}
      {vista === "che" && <Checador clave={clave} admin={yo.rol === "admin"} />}
      {vista === "flo" && <Flotilla clave={clave} admin={yo.rol === "admin"} />}
      {vista === "eva" && <Evaluaciones clave={clave} />}
      {vista === "ia" && <BusquedaIA clave={clave} />}
      {vista === "edi" && yo.rol === "admin" && <ReglamentoEditor clave={clave} />}
      {vista === "dep" && yo.rol === "admin" && <DepartamentosEditor clave={clave} />}
      {vista === "pla" && yo.rol === "admin" && <PlanesEditor clave={clave} />}
      {vista === "lic" && yo.rol === "admin" && <Licenciamiento clave={clave} />}
      {vista === "acc" && <Accidentes clave={clave} />}
      {vista === "ope" && <Operativos clave={clave} />}
      {vista === "bit" && <Bitacora clave={clave} />}
      {vista === "reg" && <Reglamento />}
      {vista === "rep" && (
        <div className="card">
          <h2>Reportes ciudadanos ({reportes?.length ?? 0})</h2>
          {reportes?.map((r) => (
            <details key={r._id}>
              <summary>{r.folio} · {r.tipo}<span className="tag">{r.estatus}</span></summary>
              <p>
                {r.ubicacion}<br />{r.descripcion}
                {r.latitud !== undefined && r.longitud !== undefined && (
                  <><br /><a href={`https://www.google.com/maps?q=${r.latitud},${r.longitud}`} target="_blank" rel="noreferrer">Ver en el mapa</a></>
                )}
              </p>
              <select value={r.estatus} onChange={(e) => cambiar({ clave, id: r._id, estatus: e.target.value })}>
                {ESTATUS.map((s) => <option key={s}>{s}</option>)}
              </select>
            </details>
          ))}
        </div>
      )}
      {vista === "map" && (
        <div className="card">
          <h2>Mapa de reportes abiertos</h2>
          <MapaReportes />
        </div>
      )}
      {vista === "mul" && (
        <>
          <div className="card">
            <h2>Registrar multa</h2>
            <label>Placa</label>
            <input value={placa} onChange={(e) => setPlaca(e.target.value.toUpperCase())} placeholder="ABC-123-A" />
            <label>Tipo de placa</label>
            <select value={tipoPlaca} onChange={(e) => setTipoPlaca(e.target.value)}>{TIPOS_PLACA.map((t) => <option key={t}>{t}</option>)}</select>
            <label>Infracción (catálogo)</label>
            <select value={infId} onChange={(e) => setInfId(e.target.value)}>
              <option value="">Selecciona…</option>
              {infs?.map((i) => <option key={i._id} value={i._id} disabled={i.verificada === false}>{i.clave} · {i.descripcion}{i.verificada === false ? " (sin verificar)" : ""}</option>)}
            </select>
            {sel && uma !== undefined && <p className="note">Se aplicará: {sel.umasMin * (causo ? 2 : 1)} UMA × {mxn(uma)} = {mxn(Math.round(sel.umasMin * (causo ? 2 : 1) * uma * 100) / 100)}</p>}
            <label><input type="checkbox" checked={causo} onChange={(e) => setCauso(e.target.checked)} style={{ width: "auto", marginRight: 8 }} />La infracción causó un accidente (se aplica al 200%)</label>
            <label>Observaciones</label>
            <textarea rows={2} value={obs} onChange={(e) => setObs(e.target.value)} />
            <button className="btn" onClick={alta}>Guardar multa</button>
            <p className="note">{msg}</p>
          </div>
          <div className="card">
            <h2>Multas registradas ({multas?.length ?? 0})</h2>
            {multas?.map((m) => (
              <div className="row" key={m._id}>
                <div>
                  <b>{m.folio}</b> · {m.placa}<br />{m.motivo} · {mxn(m.monto)}{m.montoUmas ? ` (${m.montoUmas} UMA)` : ""}{" "}
                  <span className={"st " + (m.pagada ? "ok" : "bad")}>{m.pagada ? "PAGADA" : "PENDIENTE"}</span>
                </div>
                {!m.pagada && <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => pagar({ clave, id: m._id })}>Marcar pagada</button>}
              </div>
            ))}
          </div>
        </>
      )}
      {vista === "cat" && (
        <>
          <TipoCambio clave={clave} />
          <div className="card">
            <h2>Valor de la UMA</h2>
            <p className="note" style={{ marginTop: 0 }}>Vigente: {uma !== undefined ? mxn(uma) : "…"} (la UMA 2026 publicada por el INEGI es $117.31, vigente del 1 de febrero de 2026 al 31 de enero de 2027).</p>
            <input inputMode="decimal" value={umaNueva} onChange={(e) => setUmaNueva(e.target.value)} placeholder="Nuevo valor diario" />
            <button className="btn" onClick={async () => { try { await fijarUma({ clave, valor: Number(umaNueva) }); setUmaNueva(""); setMsg("UMA actualizada."); } catch { setMsg("Valor no válido."); } }}>Actualizar UMA</button>
            <p className="note">{msg}</p>
          </div>
          <div className="card">
            <h2>Agregar infracción</h2>
            <input value={cInf} onChange={(e) => setCInf(e.target.value)} placeholder="Clave o artículo del reglamento" />
            <input value={cDesc} onChange={(e) => setCDesc(e.target.value)} placeholder="Descripción" />
            <input inputMode="decimal" value={cMin} onChange={(e) => setCMin(e.target.value)} placeholder="UMAs mínimo" />
            <input inputMode="decimal" value={cMax} onChange={(e) => setCMax(e.target.value)} placeholder="UMAs máximo" />
            <button className="btn" onClick={altaInf}>{editId ? "Guardar cambios" : "Agregar al catálogo"}</button>
          </div>
          <div className="card">
            <h2>Catálogo ({infs?.length ?? 0})</h2>
            {infs?.length === 0 && <button className="btn" onClick={async () => { try { const n = await sembrar({ clave }); setMsg(n + " partidas base cargadas (sin verificar)."); } catch { setMsg("No se pudo cargar."); } }}>Cargar partidas base del tabulador</button>}
            {infs?.map((i) => (
              <div className="row" key={i._id}>
                <div>
                  <b>{i.clave}</b> · {i.descripcion}<br />{i.umasMin}–{i.umasMax} UMA{" "}
                  <span className={"st " + (i.verificada === false ? "bad" : "ok")}>{i.verificada === false ? "SIN VERIFICAR" : "VERIFICADA"}</span>
                  {i.fuente && <><br /><span className="note" style={{ margin: 0 }}>{i.fuente}</span></>}
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {i.verificada === false && <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => verifPartida({ clave, id: i._id })}>Verificar</button>}
                  <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => { setEditId(i._id); setCInf(i.clave); setCDesc(i.descripcion); setCMin(String(i.umasMin)); setCMax(String(i.umasMax)); window.scrollTo(0, 0); }}>Editar</button>
                  <button className="btn sm" style={{ marginBottom: 0, background: "var(--bad)" }} onClick={() => { if (confirm("¿Borrar esta infracción?")) borrarInf({ clave, id: i._id }); }}>Borrar</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}

class Guard extends Component<{ children: ReactNode; onFail: () => void }, { fail: boolean }> {
  state = { fail: false };
  static getDerivedStateFromError() {
    return { fail: true };
  }
  render() {
    if (!this.state.fail) return this.props.children;
    return (
      <div className="card">
        <p className="bad">La sesión ya no es válida (clave cambiada o acceso retirado).</p>
        <button className="btn" onClick={this.props.onFail}>Intentar de nuevo</button>
      </div>
    );
  }
}

function Admin() {
  const [entrada, setEntrada] = useState("");
  const [clave, setClave] = useState("");
  const yo = useQuery(api.oficiales.yo, clave ? { clave } : "skip");

  useEffect(() => {
    try {
      const s = sessionStorage.getItem("clave");
      if (s) setClave(s);
    } catch {
      /* sin almacenamiento */
    }
  }, []);
  const entrar = () => {
    const c = entrada.trim();
    setClave(c);
    try { sessionStorage.setItem("clave", c); } catch { /* sin almacenamiento */ }
  };
  const salir = () => {
    setClave("");
    setEntrada("");
    try { sessionStorage.removeItem("clave"); } catch { /* sin almacenamiento */ }
  };

  return (
    <div className="tr">
      <style>{CSS}</style>
      <header className="hero">
        <img src={LOGO} alt="Escudo Tránsito y Vialidad Reynosa" />
        <h1>Panel del personal</h1>
        <p>Secretaría de Seguridad Pública, Vialidad y Tránsito</p>
      </header>
      <main>
        {!clave || yo === null ? (
          <div className="card">
            <h2>Acceso del personal</h2>
            <label>Tu clave personal</label>
            <input type="password" value={entrada} onChange={(e) => setEntrada(e.target.value)} autoComplete="off" />
            <button className="btn" onClick={entrar}>Entrar</button>
            {clave && yo === null && <p className="note bad">Clave incorrecta o sin acceso.</p>}
            <p className="note">Cada oficial tiene su propia clave. Si no la tienes, pídela a Administración.</p>
          </div>
        ) : yo === undefined ? (
          <p className="note">Verificando…</p>
        ) : (
          <Guard onFail={salir}>
            <Panel clave={clave} yo={yo as Yo} salir={salir} />
          </Guard>
        )}
      </main>
    </div>
  );
}
