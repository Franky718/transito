import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import { MacalyBridge } from '@macaly/bridge'
import AppConvexProvider from '@/components/convex-client-provider'

// CSS imported as a side effect — do NOT add `?url` or `?inline`.
import '../styles.css'
import siteMetadata from '../metadata.json'

const rootMeta = siteMetadata['/']

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover' },
      { title: rootMeta.title },
      { name: 'description', content: rootMeta.description },
      { name: 'theme-color', content: '#0b3a78' },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-title', content: 'Tránsito Reynosa' },
    ],
    links: [
      { rel: 'icon', type: 'image/png', href: '/logo192.png' },
      { rel: 'apple-touch-icon', href: '/logo192.png' },
      { rel: 'manifest', href: '/manifest.json' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <MacalyBridge>
        <body>
          <AppConvexProvider>{children}</AppConvexProvider>
          <Scripts />
        </body>
      </MacalyBridge>
    </html>
  )
}
