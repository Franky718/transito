import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { CSS, LOGO } from "@/lib/ui";
import { Instalar, Reglamento } from "@/components/app-extras";
import MapaReportes from "@/components/mapa-reportes";
import { Directorio, Evaluar, Tabulador } from "@/components/ciudadano";

export const Route = createFileRoute("/")({ component: Home });

const TIPOS = ["Semáforo descompuesto", "Vehículo obstruyendo cochera", "Auto en estado de abandono", "Otro"];

function Home() {
  const [tab, setTab] = useState<"reg" | "tab" | "rep" | "map" | "mul">("reg");
  const [folios, setFolios] = useState<string[]>([]);
  const [tipo, setTipo] = useState(TIPOS[0]);
  const [ubi, setUbi] = useState("");
  const [desc, setDesc] = useState("");
  const [msg, setMsg] = useState("");
  const [coords, setCoords] = useState<{ latitud: number; longitud: number } | null>(null);
  const [placa, setPlaca] = useState("");
  const [buscada, setBuscada] = useState("");

  const crear = useMutation(api.reportes.crear);
  const mis = useQuery(api.reportes.porFolios, { folios });
  const stats = useQuery(api.reportes.estadisticas);
  const lista = useQuery(api.multas.consultarVehiculo, buscada ? { placa: buscada } : "skip");

  useEffect(() => {
    try {
      setFolios(JSON.parse(localStorage.getItem("folios") || "[]") as string[]);
    } catch {
      setFolios([]);
    }
  }, []);

  const enviar = async () => {
    if (!ubi.trim()) return setMsg("Indica la ubicación.");
    try {
      const f = await crear({ tipo, ubicacion: ubi, descripcion: desc, ...(coords ?? {}) });
      const next = [f, ...folios];
      setFolios(next);
      try {
        localStorage.setItem("folios", JSON.stringify(next));
      } catch {
        /* sin almacenamiento */
      }
      setMsg("Reporte enviado. Folio: " + f);
      setUbi("");
      setDesc("");
    } catch {
      setMsg("No se pudo enviar. Intenta de nuevo.");
    }
  };

  const gps = () => {
    if (!navigator.geolocation) return setMsg("Tu dispositivo no permite ubicación.");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setCoords({ latitud: p.coords.latitude, longitud: p.coords.longitude });
        setUbi(p.coords.latitude.toFixed(5) + ", " + p.coords.longitude.toFixed(5));
      },
      () => setMsg("No se pudo obtener la ubicación."),
    );
  };

  const tabs = [["reg", "📖", "Reglamento"], ["tab", "💲", "Tabulador"], ["rep", "📍", "Reportar"], ["map", "🗺️", "Mapa"], ["mul", "💳", "Multas"]] as const;

  return (
    <div className="tr">
      <style>{CSS}</style>
      <header className="hero">
        <img src={LOGO} alt="Escudo Tránsito y Vialidad Reynosa" />
        <h1>Secretaría de Seguridad Pública, Vialidad y Tránsito</h1>
        <p>Reynosa, Tamaulipas · Servicios ciudadanos</p>
      </header>
      <main>
        <Instalar />
        {tab === "reg" && <Reglamento />}
        {tab === "reg" && <Directorio />}
        {tab === "tab" && <Tabulador />}
        {tab === "rep" && (
          <>
            <div className="card">
              <div className="ban"><img src={LOGO} alt="" /><b>Secretaría de Seguridad Pública, Vialidad y Tránsito</b></div>
              <h2>📍 Reporte ciudadano</h2>
              <label>Tipo de incidencia</label>
              <select value={tipo} onChange={(e) => setTipo(e.target.value)}>{TIPOS.map((t) => <option key={t}>{t}</option>)}</select>
              <label>Ubicación (calle, colonia, referencia)</label>
              <input value={ubi} onChange={(e) => setUbi(e.target.value)} placeholder="Ej. Blvd. Hidalgo y Calle 16, col. Centro" />
              <button className="btn sm" onClick={gps}>Usar mi ubicación</button>
              <label>Descripción</label>
              <textarea rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Describe lo que ocurre" />
              <button className="btn" onClick={enviar}>Enviar reporte</button>
              <p className="note">{msg}</p>
            </div>
            <div className="card">
              <h2>Mis reportes</h2>
              {(!mis || mis.length === 0) && <p className="note">Aún no has enviado reportes.</p>}
              {mis?.map((r) => (
                <details key={r.folio}>
                  <summary>{r.folio} · {r.tipo}</summary>
                  <p>
                    <span className="cmp"><img src={LOGO} alt="" />Comprobante · Seguridad Pública, Vialidad y Tránsito</span><br />
                    {r.ubicacion}<br />{r.descripcion}<br />
                    <b className={r.estatus === "Atendido" ? "ok" : ""}>Estatus: {r.estatus}</b>
                  </p>
                </details>
              ))}
            </div>
          </>
        )}
        {tab === "map" && (
          <div className="card">
            <h2>🗺️ Mapa de incidencias</h2>
            <p className="note" style={{ marginTop: 0 }}>Reportes ciudadanos abiertos con ubicación. Rojo: recién recibido. Ámbar: en atención.</p>
            <MapaReportes publico />
          </div>
        )}
        {tab === "mul" && (
          <>
            <div className="card">
              <h2>💳 Consulta de multas</h2>
              <label>Placa del vehículo</label>
              <input value={placa} onChange={(e) => setPlaca(e.target.value.toUpperCase())} placeholder="Ej. ABC-123-A" />
              <button className="btn" onClick={() => setBuscada(placa.trim().toUpperCase().replace(/\s+/g, ""))}>Consultar</button>
              <div style={{ marginTop: 12 }}>
                {buscada && lista && lista.multas.length === 0 && !lista.estatus_corralon && <p className="note">Sin multas ni ingreso a corralón registrados para esa placa.</p>}
                {lista?.estatus_corralon && (
                  <p className="note"><b>Corralón:</b> {lista.estatus_corralon.estatus} (folio {lista.estatus_corralon.folio}). Acude a los canales oficiales para su liberación.</p>
                )}
                {lista && lista.multas_pendientes > 0 && (
                  <p className="note"><b>Total pendiente:</b> ${lista.total_a_pagar_mxn.toLocaleString("es-MX")} MXN{lista.total_a_pagar_umas ? " (" + lista.total_a_pagar_umas + " UMA)" : ""} en {lista.multas_pendientes} multa(s)</p>
                )}
                {lista?.multas.map((x) => (
                  <div className="row" key={x.folio}>
                    <div>
                      <b>{x.folio}</b> · {x.motivo}<br />${x.monto.toLocaleString("es-MX")} MXN{x.montoUmas ? " (" + x.montoUmas + " UMA)" : ""}{" "}
                      <span className={"st " + (x.pagada ? "ok" : "bad")}>{x.pagada ? "PAGADA" : "PENDIENTE"}</span>
                    </div>
                  </div>
                ))}
              </div>
              <p className="note">El pago en línea se habilitará con la pasarela oficial del municipio. Mientras tanto, paga solo en los canales oficiales y conserva tu folio.</p>
            </div>
            <div className="card">
              <h2>🔎 Transparencia</h2>
              <div className="stats">
                <div><b>{stats?.total ?? 0}</b><span>Reportes recibidos</span></div>
                <div><b>{stats?.atendidos ?? 0}</b><span>Atendidos</span></div>
                <div><b>0</b><span>Cobros en efectivo en operativo</span></div>
              </div>
              <p className="note">Toda multa debe tener folio, fundamento y pago por canales oficiales. Para denunciar cobros indebidos, use Reportar → Otro.</p>
            </div>
          </>
        )}
        {tab === "mul" && <Evaluar />}
        <p className="note" style={{ textAlign: "center" }}><a href="/admin">Acceso del personal</a></p>
      </main>
      <nav>
        {tabs.map(([k, i, l]) => (
          <button key={k} className={tab === k ? "on" : ""} onClick={() => { setTab(k); window.scrollTo(0, 0); }}><span>{i}</span>{l}</button>
        ))}
      </nav>
    </div>
  );
}
