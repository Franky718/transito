import { useEffect, useRef, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

// Leaflet y su capa de calor se cargan desde CDN solo en el navegador.
type LHeat = { setLatLngs(p: number[][]): LHeat; addTo(m: LMap): LHeat };
type LMap = { setView(c: [number, number], z: number): LMap; remove(): void };
type LLib = {
  map(el: HTMLElement): LMap;
  tileLayer(url: string, o: { attribution: string }): { addTo(m: LMap): unknown };
  heatLayer(p: number[][], o: object): LHeat;
};
const V = "1.9.4";
const CENTRO: [number, number] = [26.0924, -98.2831];

function script(src: string) {
  return new Promise<void>((ok, no) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = () => ok();
    s.onerror = () => no(new Error("carga"));
    document.head.appendChild(s);
  });
}
async function cargar(): Promise<LLib> {
  const w = window as unknown as { L?: LLib };
  if (!w.L) {
    const css = document.createElement("link");
    css.rel = "stylesheet";
    css.href = `https://unpkg.com/leaflet@${V}/dist/leaflet.css`;
    document.head.appendChild(css);
    await script(`https://unpkg.com/leaflet@${V}/dist/leaflet.js`);
  }
  if (!w.L!.heatLayer) await script("https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js");
  return w.L!;
}

export default function MapaCalor({ clave }: { clave: string }) {
  const [dias, setDias] = useState("30");
  const [capa, setCapa] = useState("todos");
  const pts = useQuery(api.operativo.puntosCalor, { clave, dias: Number(dias), capa });
  const el = useRef<HTMLDivElement>(null);
  const ref = useRef<{ map: LMap; heat: LHeat } | null>(null);
  const [listo, setListo] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    let vivo = true;
    cargar()
      .then((L) => {
        if (!vivo || !el.current) return;
        const map = L.map(el.current).setView(CENTRO, 12);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>',
        }).addTo(map);
        ref.current = { map, heat: L.heatLayer([], { radius: 28, blur: 20, maxZoom: 15 }).addTo(map) };
        setListo(true);
      })
      .catch(() => setError(true));
    return () => {
      vivo = false;
      ref.current?.map.remove();
      ref.current = null;
      setListo(false);
    };
  }, []);

  useEffect(() => {
    if (listo && ref.current && pts) ref.current.heat.setLatLngs(pts);
  }, [listo, pts]);

  return (
    <div className="card">
      <h2>🔥 Mapa de calor</h2>
      <div className="stats" style={{ textAlign: "left" }}>
        <div>
          <label>Periodo</label>
          <select value={dias} onChange={(e) => setDias(e.target.value)}>
            <option value="7">7 días</option><option value="30">30 días</option><option value="90">90 días</option><option value="365">1 año</option>
          </select>
        </div>
        <div style={{ gridColumn: "span 2" }}>
          <label>Capa</label>
          <select value={capa} onChange={(e) => setCapa(e.target.value)}>
            <option value="todos">Accidentes y reportes</option><option value="accidentes">Solo accidentes</option><option value="reportes">Solo reportes ciudadanos</option>
          </select>
        </div>
      </div>
      <div ref={el} style={{ height: 420, width: "100%", borderRadius: 12, overflow: "hidden" }} />
      {error && <p className="note">No se pudo cargar el mapa. Revisa tu conexión.</p>}
      <p className="note">{pts ? `${pts.length} punto(s) con ubicación. ` : ""}Los accidentes con lesionados o fallecidos pesan más. Las multas aún no se ubican en el mapa porque no registran coordenadas.</p>
    </div>
  );
}
