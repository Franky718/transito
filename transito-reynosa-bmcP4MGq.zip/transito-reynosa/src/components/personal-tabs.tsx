import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

const mxn = (n: number) => "$" + n.toLocaleString("es-MX", { maximumFractionDigits: 0 });
const cuando = (t: number) => new Date(t).toLocaleString("es-MX", { dateStyle: "short", timeStyle: "short" });

export function Inicio({ clave }: { clave: string }) {
  const r = useQuery(api.personal.resumen, { clave });
  return (
    <>
      <div className="card">
        <h2>Resumen</h2>
        <div className="stats">
          <div><b>{r?.reportesAbiertos ?? 0}</b><span>Reportes abiertos</span></div>
          <div><b>{r?.multasPendientes ?? 0}</b><span>Multas pendientes</span></div>
          <div><b>{r ? mxn(r.montoPendiente) : "$0"}</b><span>Por cobrar</span></div>
        </div>
        <div className="stats" style={{ marginTop: 12 }}>
          <div><b>{r?.accidentes ?? 0}</b><span>Accidentes</span></div>
          <div><b>{r ? r.lesionados + r.fallecidos : 0}</b><span>Víctimas</span></div>
          <div><b>{r?.operativosProgramados ?? 0}</b><span>Operativos próximos</span></div>
        </div>
      </div>
      <div className="card">
        <h2>Teléfonos de emergencia</h2>
        {[["911", "Emergencias"], ["089", "Denuncia anónima"], ["065", "Cruz Roja"]].map(([n, d]) => (
          <div className="row" key={n}><div><b>{d}</b></div><a className="btn sm" style={{ marginBottom: 0, textDecoration: "none", textAlign: "center" }} href={`tel:${n}`}>Llamar {n}</a></div>
        ))}
      </div>
      <div className="card">
        <h2>Guías rápidas</h2>
        <details><summary>Al levantar una infracción (Art. 3)</summary>
          <p>1) Indica el alto y estaciona en lugar seguro. 2) Identifícate con nombre y número de agente. 3) Informa la falta. 4) Pide licencia, tarjeta de circulación y seguro. 5) Decide: notificación verbal, amonestación o boleta. 6) Entrega o captura las boletas al terminar el turno.</p></details>
        <details><summary>Si hay sospecha de alcohol o drogas (Art. 4 y 6)</summary>
          <p>Examen médico o alcoholímetro. Se impide la conducción y el vehículo va al lote en grúa. Si el conductor es menor de edad, avisa de inmediato a sus padres o tutor.</p></details>
        <details><summary>En un accidente con lesionados o fallecidos (Art. 113 y 116)</summary>
          <p>Solicita auxilio médico, abandera y preserva la escena, no muevas cuerpos, avisa al Ministerio Público, obtén dictamen médico cuando aplique y entrega tu reporte por escrito al terminar el turno.</p></details>
        <details><summary>Accidente solo con daños materiales (Art. 114)</summary>
          <p>Las partes pueden llegar a un acuerdo (acta convenio, sin lesionados ni alcohol o drogas). Si no hay acuerdo, se presentan ante el Juez calificador; si alguien no acepta, pasa al Ministerio Público.</p></details>
        <details><summary>Vehículo abandonado u obstruyendo (Art. 2)</summary>
          <p>Se fija aviso por 24 horas. Si no se retira, se envía con grúa al lote autorizado. Para devolverlo: comprobar propiedad y pagar multas y derechos (Art. 7).</p></details>
      </div>
    </>
  );
}

export function Accidentes({ clave }: { clave: string }) {
  const lista = useQuery(api.personal.accidentesListar, { clave });
  const crear = useMutation(api.personal.accidentesCrear);
  const estatus = useMutation(api.personal.accidentesEstatus);
  const [f, setF] = useState({ tipo: "Impacto por alcance", ubicacion: "", lesionados: "0", fallecidos: "0", vehiculos: "1", descripcion: "", oficialId: "" });
  const [pos, setPos] = useState<{ latitud: number; longitud: number } | null>(null);
  const [msg, setMsg] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const gps = () =>
    navigator.geolocation?.getCurrentPosition(
      (p) => { setPos({ latitud: p.coords.latitude, longitud: p.coords.longitude }); setF({ ...f, ubicacion: f.ubicacion || p.coords.latitude.toFixed(5) + ", " + p.coords.longitude.toFixed(5) }); },
      () => setMsg("No se pudo obtener la ubicación."),
    );
  const guardar = async () => {
    try {
      const folio = await crear({ clave, ...f, lesionados: Number(f.lesionados), fallecidos: Number(f.fallecidos), vehiculos: Number(f.vehiculos), ...(pos ?? {}) });
      setMsg("Parte registrado: " + folio + (Number(f.fallecidos) > 0 ? ". Con fallecidos: no muevas cuerpos y avisa al Ministerio Público (Art. 113 y 116)." : ""));
      setF({ ...f, ubicacion: "", descripcion: "", lesionados: "0", fallecidos: "0", vehiculos: "1" });
      setPos(null);
    } catch {
      setMsg("Revisa ubicación y oficial.");
    }
  };
  return (
    <>
      <div className="card">
        <h2>Parte de hechos de tránsito</h2>
        <label>Tipo</label>
        <select value={f.tipo} onChange={set("tipo")}>
          {["Impacto por alcance", "Impacto frontal", "Impacto lateral", "Contra objeto fijo", "Volcadura", "Salida del camino", "Atropellamiento a persona", "Caída de pasajero", "Otro"].map((t) => <option key={t}>{t}</option>)}
        </select>
        <label>Ubicación</label>
        <input value={f.ubicacion} onChange={set("ubicacion")} placeholder="Calle, colonia, referencia" />
        <button className="btn sm" onClick={gps}>Usar mi ubicación</button>
        <div className="stats" style={{ textAlign: "left", marginBottom: 10 }}>
          <div><label>Lesionados</label><input inputMode="numeric" value={f.lesionados} onChange={set("lesionados")} /></div>
          <div><label>Fallecidos</label><input inputMode="numeric" value={f.fallecidos} onChange={set("fallecidos")} /></div>
          <div><label>Vehículos</label><input inputMode="numeric" value={f.vehiculos} onChange={set("vehiculos")} /></div>
        </div>
        <label>Descripción de los hechos</label>
        <textarea rows={3} value={f.descripcion} onChange={set("descripcion")} />
        <button className="btn" onClick={guardar}>Guardar parte</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Accidentes registrados ({lista?.length ?? 0})</h2>
        {lista?.map((a) => (
          <details key={a._id}>
            <summary>{a.folio} · {a.tipo}<span className="tag">{a.estatus}</span></summary>
            <p>{cuando(a._creationTime)} · {a.ubicacion}<br />Vehículos: {a.vehiculos} · Lesionados: {a.lesionados} · Fallecidos: {a.fallecidos}<br />{a.descripcion}<br />Oficial: {a.oficialId}
              {a.latitud !== undefined && a.longitud !== undefined && <><br /><a href={`https://www.google.com/maps?q=${a.latitud},${a.longitud}`} target="_blank" rel="noreferrer">Ver en el mapa</a></>}</p>
            <select value={a.estatus} onChange={(e) => estatus({ clave, id: a._id, estatus: e.target.value })}>
              {["Abierto", "Convenio", "Turnado al MP", "Cerrado"].map((s) => <option key={s}>{s}</option>)}
            </select>
          </details>
        ))}
      </div>
    </>
  );
}

export function Operativos({ clave }: { clave: string }) {
  const lista = useQuery(api.personal.operativosListar, { clave });
  const crear = useMutation(api.personal.operativosCrear);
  const estado = useMutation(api.personal.operativosEstado);
  const [f, setF] = useState({ nombre: "", tipo: "Alcoholímetro", ubicacion: "", fecha: "", hora: "20:00", personal: "4" });
  const [msg, setMsg] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const guardar = async () => {
    try {
      await crear({ clave, ...f, personal: Number(f.personal) });
      setMsg("Operativo programado.");
      setF({ ...f, nombre: "", ubicacion: "" });
    } catch {
      setMsg("Revisa nombre, ubicación y fecha.");
    }
  };
  return (
    <>
      <div className="card">
        <h2>Programar operativo</h2>
        <input value={f.nombre} onChange={set("nombre")} placeholder="Nombre del operativo" />
        <select value={f.tipo} onChange={set("tipo")}>{["Alcoholímetro", "Vigilancia", "Zona escolar", "Revisión de documentos", "Evento masivo", "Otro"].map((t) => <option key={t}>{t}</option>)}</select>
        <input value={f.ubicacion} onChange={set("ubicacion")} placeholder="Ubicación" />
        <div className="stats" style={{ textAlign: "left" }}>
          <div><label>Fecha</label><input type="date" value={f.fecha} onChange={set("fecha")} /></div>
          <div><label>Hora</label><input type="time" value={f.hora} onChange={set("hora")} /></div>
          <div><label>Personal</label><input inputMode="numeric" value={f.personal} onChange={set("personal")} /></div>
        </div>
        <button className="btn" onClick={guardar}>Programar</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Operativos ({lista?.length ?? 0})</h2>
        {lista?.map((o) => (
          <details key={o._id}>
            <summary>{o.fecha} {o.hora} · {o.nombre}<span className="tag">{o.estado}</span></summary>
            <p>{o.tipo} · {o.ubicacion} · {o.personal} elementos</p>
            <select value={o.estado} onChange={(e) => estado({ clave, id: o._id, estado: e.target.value })}>
              {["Programado", "Realizado", "Cancelado"].map((s) => <option key={s}>{s}</option>)}
            </select>
          </details>
        ))}
      </div>
    </>
  );
}

export function Bitacora({ clave }: { clave: string }) {
  const lista = useQuery(api.personal.bitacoraListar, { clave });
  const crear = useMutation(api.personal.bitacoraCrear);
  const [turno, setTurno] = useState("Matutino");
  const [texto, setTexto] = useState("");
  const [msg, setMsg] = useState("");
  const guardar = async () => {
    try {
      await crear({ clave, turno, texto });
      setTexto("");
      setMsg("Novedad registrada.");
    } catch {
      setMsg("Escribe la novedad.");
    }
  };
  return (
    <>
      <div className="card">
        <h2>Bitácora de turno</h2>
        <select value={turno} onChange={(e) => setTurno(e.target.value)}>{["Matutino", "Vespertino", "Nocturno"].map((t) => <option key={t}>{t}</option>)}</select>
        <textarea rows={3} value={texto} onChange={(e) => setTexto(e.target.value)} placeholder="Novedades del turno, revisión de unidad, equipo, incidentes…" />
        <button className="btn" onClick={guardar}>Registrar novedad</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Últimas novedades</h2>
        {lista?.length === 0 && <p className="note">Sin registros todavía.</p>}
        {lista?.map((b) => (
          <div className="row" key={b._id}><div><b>{b.turno}</b> · {b.oficialId} · {cuando(b._creationTime)}<br />{b.texto}</div></div>
        ))}
      </div>
    </>
  );
}

export function Oficiales({ clave }: { clave: string }) {
  const lista = useQuery(api.oficiales.listar, { clave });
  const crear = useMutation(api.oficiales.crear);
  const regenerar = useMutation(api.oficiales.regenerar);
  const activar = useMutation(api.oficiales.activar);
  const [nombre, setNombre] = useState("");
  const [numero, setNumero] = useState("");
  const [rol, setRol] = useState("oficial");
  const [nueva, setNueva] = useState<{ para: string; clave: string } | null>(null);
  const [msg, setMsg] = useState("");
  const alta = async () => {
    try {
      const r = await crear({ clave, nombre, numero, rol });
      setNueva({ para: nombre + " (" + numero.toUpperCase() + ")", clave: r.clave });
      setNombre(""); setNumero(""); setMsg("");
    } catch {
      setMsg("Revisa nombre y número (el número no puede repetirse).");
    }
  };
  return (
    <>
      {nueva && (
        <div className="card" style={{ borderColor: "var(--ac)" }}>
          <h2>Clave de {nueva.para}</h2>
          <p style={{ fontSize: 28, letterSpacing: 4, fontWeight: 700, margin: "6px 0" }}>{nueva.clave}</p>
          <p className="note">Entrégala solo a esa persona. Solo se muestra ahora: el sistema guarda únicamente su huella y no puede mostrarla de nuevo (si se pierde, genera una nueva).</p>
          <button className="btn sm" onClick={() => setNueva(null)}>Ya la anoté</button>
        </div>
      )}
      <div className="card">
        <h2>Dar acceso a un oficial</h2>
        <input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre completo" />
        <input value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="Número de placa o de empleado" />
        <select value={rol} onChange={(e) => setRol(e.target.value)}>
          <option value="oficial">Oficial (reportes, accidentes, operativos, bitácora, multas)</option>
          <option value="admin">Administración (además: catálogo, UMA, cobros y oficiales)</option>
        </select>
        <button className="btn" onClick={alta}>Crear acceso y generar clave</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Personal con acceso ({lista?.length ?? 0})</h2>
        {lista?.map((o) => (
          <div className="row" key={o._id} style={{ flexWrap: "wrap" }}>
            <div><b>{o.nombre}</b> · {o.numero}<br /><span className={"st " + (o.activo ? "ok" : "bad")}>{o.activo ? "ACTIVO" : "SIN ACCESO"}</span> · {o.rol === "admin" ? "Administración" : "Oficial"}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button className="btn sm" style={{ marginBottom: 0 }} onClick={async () => { const r = await regenerar({ clave, id: o._id }); setNueva({ para: o.nombre + " (" + o.numero + ")", clave: r.clave }); }}>Nueva clave</button>
              <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => activar({ clave, id: o._id, activo: !o.activo })}>{o.activo ? "Quitar acceso" : "Dar acceso"}</button>
            </div>
          </div>
        ))}
        <p className="note">La clave maestra de Jefatura sigue funcionando como respaldo. Cámbiala periódicamente.</p>
      </div>
    </>
  );
}
