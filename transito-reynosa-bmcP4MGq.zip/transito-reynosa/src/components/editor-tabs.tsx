import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";
import { ARTICULOS } from "@/lib/reglamento";

const DEPTOS = [
  { clave: "dir_transito", nombre: "Dirección de Tránsito y Vialidad", descripcion: "Control operativo vial, multas y semaforización." },
  { clave: "dir_juridica", nombre: "Dirección Jurídica", descripcion: "Asuntos legales, normatividad y juicios de nulidad." },
  { clave: "dir_enlace_social", nombre: "Dirección de Enlace Social", descripcion: "Programas de prevención del delito, educación vial y proximidad ciudadana." },
  { clave: "dir_academia", nombre: "Dirección de la Academia de Formación Policial", descripcion: "Capacitación, control de confianza y certificación de elementos." },
  { clave: "dir_operativa", nombre: "Dirección Operativa / Policía Municipal", descripcion: "Vigilancia, operativos especiales y atención de emergencias." },
];

// ---------------- Editor del reglamento (lo que ve la ciudadanía) ----------------
export function ReglamentoEditor({ clave }: { clave: string }) {
  const lista = useQuery(api.reglamento.listar);
  const guardar = useMutation(api.reglamento.guardar);
  const borrar = useMutation(api.reglamento.borrar);
  const sembrar = useMutation(api.reglamento.sembrar);
  const [q, setQ] = useState("");
  const [id, setId] = useState<Id<"articulos"> | null>(null);
  const [f, setF] = useState({ art: "", cap: "", t: "", d: "" });
  const [msg, setMsg] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const caps = Array.from(new Set(lista?.map((x) => x.cap)));
  const visibles = lista?.filter((x) => !q.trim() || (x.art + x.t + x.d).toLowerCase().includes(q.trim().toLowerCase()));
  const enviar = async () => {
    try {
      await guardar({ clave, id: id ?? undefined, ...f });
      setMsg(id ? "Artículo actualizado." : "Artículo agregado.");
      setId(null); setF({ art: "", cap: f.cap, t: "", d: "" });
    } catch { setMsg("Completa artículo, tema, título y resumen."); }
  };
  return (
    <>
      <div className="card">
        <h2>{id ? "Editar artículo" : "Agregar artículo"}</h2>
        <p className="note" style={{ marginTop: 0 }}>Lo que guardes aquí es lo que ve la ciudadanía en la pestaña Reglamento.</p>
        <input value={f.art} onChange={set("art")} placeholder="Artículo (ej. 63 o 16–18)" />
        <input list="caps" value={f.cap} onChange={set("cap")} placeholder="Tema (ej. Estacionamiento)" />
        <datalist id="caps">{caps.map((c) => <option key={c} value={c} />)}</datalist>
        <input value={f.t} onChange={set("t")} placeholder="Título corto" />
        <textarea rows={4} value={f.d} onChange={set("d")} placeholder="Resumen en lenguaje sencillo" />
        <button className="btn" onClick={enviar}>{id ? "Guardar cambios" : "Agregar artículo"}</button>
        {id && <button className="btn sm" style={{ marginTop: 10 }} onClick={() => { setId(null); setF({ art: "", cap: "", t: "", d: "" }); }}>Cancelar edición</button>}
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Artículos publicados ({lista?.length ?? 0})</h2>
        {lista?.length === 0 && (
          <button className="btn" onClick={async () => { const n = await sembrar({ clave, articulos: ARTICULOS }); setMsg(n + " artículos base cargados."); }}>Cargar los artículos base</button>
        )}
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar para editar" />
        {visibles?.map((x) => (
          <div className="row" key={x._id}>
            <div><b>Art. {x.art}</b> · {x.t}<span className="tag">{x.cap}</span></div>
            <div style={{ display: "flex", gap: 6 }}>
              <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => { setId(x._id); setF({ art: x.art, cap: x.cap, t: x.t, d: x.d }); window.scrollTo(0, 0); }}>Editar</button>
              <button className="btn sm" style={{ marginBottom: 0, background: "var(--bad)" }} onClick={() => { if (confirm("¿Borrar Art. " + x.art + "?")) borrar({ clave, id: x._id }); }}>Borrar</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------------- Departamentos ----------------
export function DepartamentosEditor({ clave }: { clave: string }) {
  const lista = useQuery(api.institucional.departamentosListar);
  const guardar = useMutation(api.institucional.departamentosGuardar);
  const borrar = useMutation(api.institucional.departamentosBorrar);
  const sembrar = useMutation(api.institucional.departamentosSembrar);
  const [id, setId] = useState<Id<"departamentos"> | null>(null);
  const [nombre, setNombre] = useState("");
  const [desc, setDesc] = useState("");
  const [msg, setMsg] = useState("");
  return (
    <>
      <div className="card">
        <h2>{id ? "Editar departamento" : "Agregar departamento"}</h2>
        <input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre de la dirección" />
        <textarea rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Funciones" />
        <button className="btn" onClick={async () => { try { await guardar({ clave, id: id ?? undefined, nombre, descripcion: desc }); setId(null); setNombre(""); setDesc(""); setMsg("Guardado."); } catch { setMsg("Completa nombre y funciones."); } }}>{id ? "Guardar cambios" : "Agregar"}</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Departamentos ({lista?.length ?? 0})</h2>
        {lista?.length === 0 && <button className="btn" onClick={() => sembrar({ clave, lista: DEPTOS })}>Cargar las 5 direcciones base</button>}
        {lista?.map((d) => (
          <div className="row" key={d._id}>
            <div><b>{d.nombre}</b><br />{d.descripcion}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => { setId(d._id); setNombre(d.nombre); setDesc(d.descripcion); window.scrollTo(0, 0); }}>Editar</button>
              <button className="btn sm" style={{ marginBottom: 0, background: "var(--bad)" }} onClick={() => { if (confirm("¿Borrar?")) borrar({ clave, id: d._id }); }}>Borrar</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------------- Planes comerciales ----------------
export function PlanesEditor({ clave }: { clave: string }) {
  const lista = useQuery(api.institucional.planesAdmin, { clave });
  const guardar = useMutation(api.institucional.planesGuardar);
  const [id, setId] = useState<Id<"planes"> | null>(null);
  const [nombre, setNombre] = useState("");
  const [precio, setPrecio] = useState("");
  const [cars, setCars] = useState("");
  const [activo, setActivo] = useState(true);
  const [msg, setMsg] = useState("");
  const limpiar = () => { setId(null); setNombre(""); setPrecio(""); setCars(""); setActivo(true); };
  return (
    <>
      <div className="card">
        <h2>{id ? "Editar plan" : "Nuevo plan comercial"}</h2>
        <input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre del plan" />
        <input inputMode="decimal" value={precio} onChange={(e) => setPrecio(e.target.value)} placeholder="Precio mensual (MXN)" />
        <textarea rows={4} value={cars} onChange={(e) => setCars(e.target.value)} placeholder="Una característica por renglón" />
        <label><input type="checkbox" style={{ width: "auto", marginRight: 8 }} checked={activo} onChange={(e) => setActivo(e.target.checked)} />Plan activo (visible en la API pública)</label>
        <button className="btn" onClick={async () => { try { await guardar({ clave, id: id ?? undefined, nombre, precioMensual: Number(precio), caracteristicas: cars.split("\n"), activo }); limpiar(); setMsg("Plan guardado."); } catch { setMsg("Revisa nombre y precio."); } }}>{id ? "Guardar cambios" : "Crear plan"}</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Planes ({lista?.length ?? 0})</h2>
        {lista?.map((p) => (
          <div className="row" key={p._id}>
            <div><b>{p.nombre}</b> · ${p.precioMensual.toLocaleString("es-MX")}/mes <span className={"st " + (p.activo ? "ok" : "bad")}>{p.activo ? "ACTIVO" : "INACTIVO"}</span><br />{p.caracteristicas.join(" · ")}</div>
            <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => { setId(p._id); setNombre(p.nombre); setPrecio(String(p.precioMensual)); setCars(p.caracteristicas.join("\n")); setActivo(p.activo); window.scrollTo(0, 0); }}>Editar</button>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------------- Tipo de cambio referencial ----------------
export function TipoCambio({ clave }: { clave: string }) {
  const actual = useQuery(api.institucional.tipoCambio);
  const fijar = useMutation(api.institucional.fijarTipoCambio);
  const [v, setV] = useState("");
  const [msg, setMsg] = useState("");
  return (
    <div className="card">
      <h2>Tipo de cambio (dólares)</h2>
      <p className="note" style={{ marginTop: 0 }}>Referencial: {actual !== undefined ? "$" + actual.toFixed(2) + " MXN por dólar" : "…"}. Es el que usa el tabulador público para mostrar los montos en USD.</p>
      <input inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} placeholder="MXN por 1 USD" />
      <button className="btn" onClick={async () => { try { await fijar({ clave, valor: Number(v) }); setV(""); setMsg("Actualizado."); } catch { setMsg("Valor no válido."); } }}>Actualizar tipo de cambio</button>
      <p className="note">{msg}</p>
    </div>
  );
}

// ---------------- Licenciamiento y datos de pago ----------------
export function Licenciamiento({ clave }: { clave: string }) {
  const d = useQuery(api.institucional.licenciamiento, { clave });
  const m = (n: number) => "$" + n.toLocaleString("es-MX", { minimumFractionDigits: 2 }) + " MXN";
  if (!d) return <div className="card"><p className="note">Cargando…</p></div>;
  return (
    <div className="card">
      <h2>Licenciamiento y datos de pago</h2>
      {!d.configurado && (
        <p className="note bad">Faltan datos. Configura DEV_TITULAR, DEV_BANCO y DEV_CLABE (y opcionalmente DEV_CORREO, DEV_TARIFA_MENSUAL, DEV_GARANTIA) en las variables de entorno de Convex.</p>
      )}
      <p>
        <b>Titular:</b> {d.titular ?? "—"}<br />
        <b>Banco:</b> {d.banco ?? "—"}<br />
        <b>CLABE:</b> {d.clabe ?? "—"}<br />
        <b>Soporte:</b> {d.correoSoporte ?? "—"}
      </p>
      <p><b>Garantía:</b> {d.garantia}</p>
      <div className="row"><div>Tarifa mensual</div><b>{m(d.tarifaMensual)} + IVA</b></div>
      <div className="row"><div>Por año</div><b>{m(d.anual)} + IVA</b></div>
      <div className="row"><div>Trienio (36 meses)</div><b>{m(d.trienio)} + IVA</b></div>
      <p className="note">Estos datos solo los ve la administración y no están guardados en el código del proyecto.</p>
    </div>
  );
}
