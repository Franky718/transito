import { useState } from "react";
import { useAction, useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";

const mxn = (n: number) => "$" + n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const cuando = (t: number) => new Date(t).toLocaleString("es-MX", { dateStyle: "short", timeStyle: "short" });
const posicion = () =>
  new Promise<GeolocationPosition>((ok, no) => {
    if (!navigator.geolocation) return no(new Error("sin GPS"));
    navigator.geolocation.getCurrentPosition(ok, no, { enableHighAccuracy: true, timeout: 15000 });
  });

// ---------------- SOS ----------------
export function SosBoton({ clave }: { clave: string }) {
  const enviar = useMutation(api.operativo.sosEnviar);
  const [msg, setMsg] = useState("");
  const sos = async () => {
    if (!confirm("¿Enviar alerta de auxilio con tu ubicación a toda la Comandancia?")) return;
    let pos: { latitud?: number; longitud?: number } = {};
    try {
      const p = await posicion();
      pos = { latitud: p.coords.latitude, longitud: p.coords.longitude };
    } catch {
      /* se envía sin ubicación */
    }
    try {
      await enviar({ clave, ...pos });
      setMsg(pos.latitud ? "Alerta enviada con tu ubicación." : "Alerta enviada (sin ubicación: activa el GPS).");
    } catch {
      setMsg("No se pudo enviar. Llama al 911.");
    }
  };
  return (
    <div style={{ marginBottom: 10 }}>
      <button className="btn" style={{ background: "var(--ac)", color: "#fff" }} onClick={sos}>🚨 SOS · Solicitar auxilio</button>
      {msg && <p className="note">{msg}</p>}
    </div>
  );
}

export function SosActivas({ clave }: { clave: string }) {
  const l = useQuery(api.operativo.sosActivas, { clave });
  const atender = useMutation(api.operativo.sosAtender);
  if (!l || l.length === 0) return null;
  return (
    <div className="card" style={{ borderColor: "var(--ac)", borderWidth: 2 }}>
      <h2 className="bad">🚨 Alertas de auxilio ({l.length})</h2>
      {l.map((s) => (
        <div className="row" key={s._id}>
          <div>
            <b>{s.nombre}</b> · {s.oficialId}<br />{cuando(s._creationTime)}
            {s.latitud !== undefined && s.longitud !== undefined && <><br /><a href={`https://www.google.com/maps?q=${s.latitud},${s.longitud}`} target="_blank" rel="noreferrer">Ver ubicación</a></>}
          </div>
          <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => atender({ clave, id: s._id })}>Atendida</button>
        </div>
      ))}
    </div>
  );
}

// ---------------- Corralón ----------------
async function comprimir(file: File): Promise<Blob> {
  const bmp = await createImageBitmap(file);
  const esc = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * esc);
  c.height = Math.round(bmp.height * esc);
  c.getContext("2d")!.drawImage(bmp, 0, 0, c.width, c.height);
  return await new Promise((ok, no) => c.toBlob((b) => (b ? ok(b) : no(new Error("imagen"))), "image/jpeg", 0.72));
}
const CHECK = ["Carrocería sin daños", "Carrocería con golpes", "Faltan neumáticos", "Falta batería", "Falta estéreo", "Objetos de valor en cabina", "Cristales rotos", "Faltan espejos o molduras"];
const MOTIVOS = ["Infracción al reglamento", "Accidente vial", "Abandono en vía pública", "Orden judicial"];

export function Corralon({ clave }: { clave: string }) {
  const lista = useQuery(api.operativo.corralonListar, { clave });
  const ingreso = useMutation(api.operativo.corralonIngreso);
  const estatus = useMutation(api.operativo.corralonEstatus);
  const urlFoto = useMutation(api.operativo.fotoSubirUrl);
  const [revisar, setRevisar] = useState(false);
  const sellos = useQuery(api.operativo.corralonVerificarSellos, revisar ? { clave } : "skip");
  const [fotos, setFotos] = useState<{ id: Id<"_storage">; vista: string }[]>([]);
  const [subiendo, setSubiendo] = useState(false);
  const [f, setF] = useState({ empresaGrua: "", placa: "", estadoPlaca: "Tamaulipas", marca: "", linea: "", modelo: "", color: "", vin: "", motivo: MOTIVOS[0], observaciones: "" });
  const [chk, setChk] = useState<string[]>([]);
  const [msg, setMsg] = useState("");
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const subir = async (files: FileList | null) => {
    if (!files?.length) return;
    setSubiendo(true);
    try {
      const nuevas: { id: Id<"_storage">; vista: string }[] = [];
      for (const file of Array.from(files).slice(0, 8 - fotos.length)) {
        const blob = await comprimir(file);
        const url = await urlFoto({ clave });
        const r = await fetch(url, { method: "POST", headers: { "Content-Type": "image/jpeg" }, body: blob });
        if (!r.ok) throw new Error("subida");
        const { storageId } = (await r.json()) as { storageId: Id<"_storage"> };
        nuevas.push({ id: storageId, vista: URL.createObjectURL(blob) });
      }
      setFotos([...fotos, ...nuevas]);
      setMsg("");
    } catch {
      setMsg("No se pudo subir una foto. Revisa tu conexión e intenta de nuevo.");
    }
    setSubiendo(false);
  };
  const guardar = async () => {
    try {
      const r = await ingreso({ clave, ...f, modelo: Number(f.modelo) || undefined, checklist: chk, fotos: fotos.map((x) => x.id) });
      setMsg("Ingreso registrado: " + r.folio + (r.multasPendientes ? `. La placa tiene ${r.multasPendientes} multa(s) pendiente(s).` : ""));
      setF({ ...f, placa: "", marca: "", linea: "", modelo: "", color: "", vin: "", observaciones: "" });
      setChk([]);
      setFotos([]);
    } catch {
      setMsg("Revisa empresa de grúas, placa y motivo.");
    }
  };
  const cambiar = async (id: Id<"corralon">, e: string) => {
    try { await estatus({ clave, id, estatus: e }); setMsg(""); } catch { setMsg("No se puede liberar: la placa tiene multas pendientes de pago."); }
  };
  return (
    <>
      <div className="card">
        <h2>Ingreso a corralón</h2>
        <input value={f.empresaGrua} onChange={set("empresaGrua")} placeholder="Empresa de grúas concesionada" />
        <input value={f.placa} onChange={(e) => setF({ ...f, placa: e.target.value.toUpperCase() })} placeholder="Placa (ABC-123-A)" />
        <input value={f.estadoPlaca} onChange={set("estadoPlaca")} placeholder="Estado de la placa" />
        <div className="stats" style={{ textAlign: "left" }}>
          <div><input value={f.marca} onChange={set("marca")} placeholder="Marca" /></div>
          <div><input value={f.linea} onChange={set("linea")} placeholder="Línea" /></div>
          <div><input inputMode="numeric" value={f.modelo} onChange={set("modelo")} placeholder="Modelo" /></div>
        </div>
        <div className="stats" style={{ textAlign: "left" }}>
          <div><input value={f.color} onChange={set("color")} placeholder="Color" /></div>
          <div style={{ gridColumn: "span 2" }}><input value={f.vin} onChange={set("vin")} placeholder="VIN" /></div>
        </div>
        <label>Motivo de remisión</label>
        <select value={f.motivo} onChange={set("motivo")}>{MOTIVOS.map((m) => <option key={m}>{m}</option>)}</select>
        <label>Inventario físico</label>
        {CHECK.map((c) => (
          <label key={c} style={{ color: "var(--tx)" }}>
            <input type="checkbox" style={{ width: "auto", marginRight: 8 }} checked={chk.includes(c)} onChange={(e) => setChk(e.target.checked ? [...chk, c] : chk.filter((x) => x !== c))} />{c}
          </label>
        ))}
        <textarea rows={2} value={f.observaciones} onChange={set("observaciones")} placeholder="Observaciones, faltantes, objetos de valor…" />
        <label>Fotografías del vehículo ({fotos.length}/8)</label>
        <input type="file" accept="image/*" capture="environment" multiple disabled={subiendo || fotos.length >= 8} onChange={(e) => { void subir(e.target.files); e.target.value = ""; }} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, margin: "6px 0" }}>
          {fotos.map((x) => (
            <div key={x.id} style={{ position: "relative" }}>
              <img src={x.vista} alt="Foto del vehículo" style={{ width: 72, height: 72, objectFit: "cover", borderRadius: 6 }} />
              <button type="button" aria-label="Quitar foto" onClick={() => setFotos(fotos.filter((y) => y.id !== x.id))} style={{ position: "absolute", top: -6, right: -6, borderRadius: 999, border: 0, width: 22, height: 22, background: "var(--ac)", color: "#fff" }}>×</button>
            </div>
          ))}
          {subiendo && <span className="note">Subiendo…</span>}
        </div>
        <button className="btn" onClick={guardar} disabled={subiendo}>Registrar ingreso</button>
        <p className="note">{msg}</p>
      </div>
      <div className="card">
        <h2>Vehículos en corralón ({lista?.length ?? 0})</h2>
        <button className="btn sm" onClick={() => setRevisar(true)}>Verificar sello de integridad</button>
        {revisar && sellos && (
          <p className={"note " + (sellos.integra ? "ok" : "bad")}>
            {sellos.integra ? `Cadena íntegra: ${sellos.total} ingreso(s) sellado(s) sin alteraciones.` : `Se detectó una alteración en el ingreso ${sellos.rotoEn}. Avisa a Jefatura.`}
          </p>
        )}
        {lista?.map((c) => (
          <details key={c._id}>
            <summary>{c.folio} · {c.placa}<span className="tag">{c.estatus}</span></summary>
            <p>{cuando(c._creationTime)} · {c.empresaGrua} · {c.motivo}<br />{[c.marca, c.linea, c.modelo, c.color].filter(Boolean).join(" · ")}{c.vin ? ` · VIN ${c.vin}` : ""}<br />{c.checklist.join(", ") || "Sin inventario"}<br />{c.observaciones}<br />Registró: {c.oficialId}{c.sello ? <><br />Sello: {c.sello.slice(0, 16)}…</> : null}</p>
            {c.fotoUrls.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 6 }}>
                {c.fotoUrls.map((u) => <a key={u} href={u} target="_blank" rel="noreferrer"><img src={u} alt="Foto del ingreso" style={{ width: 72, height: 72, objectFit: "cover", borderRadius: 6 }} /></a>)}
              </div>
            )}
            <select value={c.estatus} onChange={(e) => cambiar(c._id, e.target.value)}>
              {["En resguardo", "En proceso de liberación", "Liberado"].map((s) => <option key={s}>{s}</option>)}
            </select>
          </details>
        ))}
      </div>
    </>
  );
}

// ---------------- Antecedentes ----------------
export function Antecedentes({ clave }: { clave: string }) {
  const [placa, setPlaca] = useState("");
  const [buscada, setBuscada] = useState("");
  const r = useQuery(api.operativo.antecedentes, buscada ? { clave, placa: buscada } : "skip");
  const color = r?.nivel === "roja" ? "var(--bad)" : r?.nivel === "naranja" ? "#d98e04" : "var(--ok)";
  const texto = r?.nivel === "roja" ? "ALERTA ROJA: vehículo en corralón sin liberar" : r?.nivel === "naranja" ? "ALERTA NARANJA: infracciones pendientes" : "SIN PENDIENTES en este sistema";
  return (
    <div className="card">
      <h2>Consulta de antecedentes</h2>
      <input value={placa} onChange={(e) => setPlaca(e.target.value.toUpperCase())} placeholder="Placa (ABC-123-A)" />
      <button className="btn" onClick={() => setBuscada(placa.trim())}>Consultar</button>
      {r && (
        <div style={{ marginTop: 12 }}>
          <div style={{ background: color, color: "#fff", borderRadius: 10, padding: 10, fontWeight: 700 }}>{texto}</div>
          <p className="note">Consulta solo los registros de este sistema. No incluye REPUVE ni reportes de robo.</p>
          <h2 style={{ marginTop: 10 }}>Multas ({r.multas.length})</h2>
          {r.multas.map((m) => (
            <div className="row" key={m.folio}><div><b>{m.folio}</b> · {m.motivo}<br />{mxn(m.monto)}{m.montoUmas ? ` (${m.montoUmas} UMA)` : ""} · {cuando(m.fecha)} <span className={"st " + (m.pagada ? "ok" : "bad")}>{m.pagada ? "PAGADA" : "PENDIENTE"}</span></div></div>
          ))}
          <h2 style={{ marginTop: 10 }}>Corralón ({r.corralon.length})</h2>
          {r.corralon.map((c) => (
            <div className="row" key={c.folio}><div><b>{c.folio}</b> · {c.motivo}<br />{cuando(c.fecha)} · {c.estatus}</div></div>
          ))}
        </div>
      )}
      {r === null && <p className="note">Escribe una placa.</p>}
    </div>
  );
}

// ---------------- Checador ----------------
const TURNOS = ["Matutino", "Vespertino", "Nocturno", "Guardia especial"];

export function Checador({ clave, admin }: { clave: string; admin: boolean }) {
  const [turno, setTurno] = useState(TURNOS[0]);
  const [msg, setMsg] = useState("");
  const [radio, setRadio] = useState("500");
  const lista = useQuery(api.operativo.asistenciaListar, { clave });
  const conf = useQuery(api.operativo.asistenciaConfig, { clave });
  const checar = useMutation(api.operativo.asistenciaChecar);
  const configurar = useMutation(api.operativo.asistenciaConfigurar);
  const registrar = async (tipo: "ENTRADA" | "SALIDA") => {
    setMsg("Obteniendo ubicación…");
    try {
      const p = await posicion();
      const r = await checar({ clave, turno, tipo, latitud: p.coords.latitude, longitud: p.coords.longitude });
      setMsg(`${tipo} registrada (${r.distanciaM} m de la Comandancia).`);
    } catch (e) {
      const m = e instanceof Error ? e.message : "";
      setMsg(m.includes("Fuera del perímetro") ? "Fuera del perímetro autorizado de la Comandancia." : "No se pudo registrar. Activa el GPS e intenta de nuevo.");
    }
  };
  const fijarAqui = async () => {
    try {
      const p = await posicion();
      await configurar({ clave, lat: p.coords.latitude, lng: p.coords.longitude, radio: Number(radio) });
      setMsg("Comandancia configurada en tu ubicación actual.");
    } catch {
      setMsg("No se pudo configurar (revisa el GPS y el radio de 50 a 5000 m).");
    }
  };
  return (
    <>
      <div className="card">
        <h2>Checador digital</h2>
        <select value={turno} onChange={(e) => setTurno(e.target.value)}>{TURNOS.map((t) => <option key={t}>{t}</option>)}</select>
        <button className="btn" style={{ background: "var(--ok)", marginBottom: 10 }} onClick={() => registrar("ENTRADA")}>Registrar entrada</button>
        <button className="btn" style={{ background: "var(--bad)" }} onClick={() => registrar("SALIDA")}>Registrar salida</button>
        <p className="note">{msg}</p>
        {conf && <p className="note">Perímetro: {conf.radio} m alrededor de {conf.lat.toFixed(4)}, {conf.lng.toFixed(4)}.</p>}
        {admin && (
          <>
            <input inputMode="numeric" value={radio} onChange={(e) => setRadio(e.target.value)} placeholder="Radio en metros" />
            <button className="btn sm" onClick={fijarAqui}>Usar mi ubicación como Comandancia</button>
            <p className="note">Hazlo estando en la Comandancia: las coordenadas de referencia iniciales son aproximadas.</p>
          </>
        )}
      </div>
      <div className="card">
        <h2>Registros</h2>
        {lista?.length === 0 && <p className="note">Sin registros.</p>}
        {lista?.map((a) => (
          <div className="row" key={a._id}><div><b>{a.tipo}</b> · {a.nombre} ({a.oficialId})<br />{a.turno} · {cuando(a._creationTime)} · {a.distanciaM} m</div></div>
        ))}
      </div>
    </>
  );
}

// ---------------- Flotilla ----------------
export function Flotilla({ clave, admin }: { clave: string; admin: boolean }) {
  const unidades = useQuery(api.operativo.unidadesListar, { clave });
  const registros = useQuery(api.operativo.unidadRegistrosListar, { clave });
  const crear = useMutation(api.operativo.unidadCrear);
  const registrar = useMutation(api.operativo.unidadRegistrar);
  const [n, setN] = useState("");
  const [t, setT] = useState("Patrulla");
  const [km0, setKm0] = useState("0");
  const [u, setU] = useState("");
  const [tipo, setTipo] = useState("Mantenimiento");
  const [desc, setDesc] = useState("");
  const [litros, setLitros] = useState("");
  const [monto, setMonto] = useState("");
  const [km, setKm] = useState("");
  const [msg, setMsg] = useState("");
  const num = (s: string) => (s.trim() && !Number.isNaN(Number(s)) ? Number(s) : undefined);
  return (
    <>
      <div className="card">
        <h2>Registrar mantenimiento o combustible</h2>
        <select value={u} onChange={(e) => setU(e.target.value)}>
          <option value="">Unidad…</option>
          {unidades?.map((x) => <option key={x._id} value={x.numero}>{x.numero} · {x.tipo} · {x.kilometraje.toLocaleString("es-MX")} km</option>)}
        </select>
        <select value={tipo} onChange={(e) => setTipo(e.target.value)}>{["Mantenimiento", "Reparación", "Combustible", "Neumáticos", "Otro"].map((x) => <option key={x}>{x}</option>)}</select>
        <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Descripción o taller" />
        <div className="stats" style={{ textAlign: "left" }}>
          <div><input inputMode="decimal" value={litros} onChange={(e) => setLitros(e.target.value)} placeholder="Litros" /></div>
          <div><input inputMode="decimal" value={monto} onChange={(e) => setMonto(e.target.value)} placeholder="Monto $" /></div>
          <div><input inputMode="numeric" value={km} onChange={(e) => setKm(e.target.value)} placeholder="Kilometraje" /></div>
        </div>
        <button className="btn" onClick={async () => { try { await registrar({ clave, numero: u, tipo, descripcion: desc, litros: num(litros), monto: num(monto), km: num(km) }); setMsg("Registrado."); setDesc(""); setLitros(""); setMonto(""); setKm(""); } catch { setMsg("Elige la unidad."); } }}>Guardar registro</button>
        <p className="note">{msg}</p>
      </div>
      {admin && (
        <div className="card">
          <h2>Agregar unidad</h2>
          <input value={n} onChange={(e) => setN(e.target.value)} placeholder="Número económico" />
          <select value={t} onChange={(e) => setT(e.target.value)}>{["Patrulla", "Motocicleta", "Grúa", "Camioneta", "Otro"].map((x) => <option key={x}>{x}</option>)}</select>
          <input inputMode="numeric" value={km0} onChange={(e) => setKm0(e.target.value)} placeholder="Kilometraje inicial" />
          <button className="btn" onClick={async () => { try { await crear({ clave, numero: n, tipo: t, kilometraje: Number(km0) || 0 }); setN(""); setMsg("Unidad agregada."); } catch { setMsg("Revisa el número (no puede repetirse)."); } }}>Agregar unidad</button>
        </div>
      )}
      <div className="card">
        <h2>Historial ({registros?.length ?? 0})</h2>
        {registros?.map((r) => (
          <div className="row" key={r._id}><div><b>{r.numero}</b> · {r.tipo} · {cuando(r._creationTime)}<br />{r.descripcion}{r.litros ? ` · ${r.litros} L` : ""}{r.monto ? ` · ${mxn(r.monto)}` : ""}{r.km ? ` · ${r.km.toLocaleString("es-MX")} km` : ""}</div></div>
        ))}
      </div>
    </>
  );
}

// ---------------- Evaluaciones ----------------
export function Evaluaciones({ clave }: { clave: string }) {
  const r = useQuery(api.operativo.evaluacionesResumen, { clave });
  return (
    <div className="card">
      <h2>Buzón de transparencia</h2>
      <div className="stats"><div><b>{r?.promedio ?? 0} ★</b><span>Promedio</span></div><div><b>{r?.total ?? 0}</b><span>Evaluaciones</span></div></div>
      {r?.recientes.map((x, i) => (
        <div className="row" key={i}><div><b>{"★".repeat(x.estrellas)}{"☆".repeat(5 - x.estrellas)}</b> · {x.referencia}<br />{x.comentario}<br /><span className="note" style={{ margin: 0 }}>{cuando(x.fecha)}</span></div></div>
      ))}
    </div>
  );
}

// ---------------- Búsqueda inteligente (IA) ----------------
export function BusquedaIA({ clave }: { clave: string }) {
  const buscar = useAction(api.ia.buscar);
  const [q, setQ] = useState("");
  const [cargando, setCargando] = useState(false);
  const [msg, setMsg] = useState("");
  const [r, setR] = useState<Awaited<ReturnType<typeof buscar>> | null>(null);
  const ir = async () => {
    setCargando(true); setMsg(""); setR(null);
    try { setR(await buscar({ clave, consulta: q })); } catch (e) {
      const m = e instanceof Error ? e.message : "";
      setMsg(m.includes("OPENAI_API_KEY") ? "La búsqueda inteligente aún no está activada: falta configurar la clave de OpenAI." : "No se pudo completar la búsqueda.");
    }
    setCargando(false);
  };
  return (
    <div className="card">
      <h2>🔎 Búsqueda inteligente</h2>
      <textarea rows={2} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ej.: accidentes de la última semana por la colonia Pedro J. Méndez" />
      <button className="btn" disabled={cargando || !q.trim()} onClick={ir}>{cargando ? "Buscando…" : "Buscar"}</button>
      <p className="note">{msg}</p>
      {r && (
        <>
          <p style={{ marginBottom: 6 }}><b>Resumen:</b> {r.resumen}</p>
          <p className="note" style={{ marginTop: 0 }}>{r.total} resultado(s). Filtros: {JSON.stringify(r.filtros)}</p>
          {r.resultados.slice(0, 30).map((x, i) => (
            <div className="row" key={i}><div><b>{x.origen}</b> · {x.tipo}<br />{x.ubicacion} · {x.estatus} · {cuando(x.fecha)}</div></div>
          ))}
        </>
      )}
      <p className="note">Solo se envían a la IA tipo, ubicación, estatus y fecha, sin textos libres ni datos personales.</p>
    </div>
  );
}
