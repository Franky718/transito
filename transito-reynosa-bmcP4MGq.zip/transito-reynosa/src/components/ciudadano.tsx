import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

const mxn = (n: number) => "$" + n.toLocaleString("es-MX", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const usd = (n: number) => "US$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const rango = (a: number, b: number, f: (n: number) => string) => (a === b ? f(a) : f(a) + " a " + f(b));

// Tabulador de multas: UMAs -> pesos -> dólares (solo partidas verificadas por la Secretaría)
export function Tabulador() {
  const [q, setQ] = useState("");
  const [umas, setUmas] = useState("");
  const t = useQuery(api.institucional.tabulador, { buscar: q });
  const n = Number(umas);
  return (
    <>
      <div className="card">
        <h2>💲 Multas en UMAs y pesos</h2>
        {t && (
          <p className="note" style={{ marginTop: 0 }}>
            Valor de la UMA vigente: <b>{mxn(t.valor_uma_vigente)}</b> (INEGI, 2026). Dólares con tipo de cambio referencial de {mxn(t.tipo_cambio_usd_referencial)} por dólar.
          </p>
        )}
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar infracción: velocidad, extintor, peatón…" />
        {t && t.partidas.length === 0 && (
          <p className="note">El tabulador oficial se está cargando. Mientras tanto, usa la calculadora de abajo para convertir UMAs a pesos.</p>
        )}
        {t?.partidas.map((p, i) => (
          <details key={i}>
            <summary>{p.descripcion}<span className="tag">Art. {p.articulo.replace("Art. ", "")}</span></summary>
            <p>
              <b>UMAs:</b> {rango(p.umas_minimo, p.umas_maximo, (x) => String(x))}<br />
              <b>Pesos:</b> {rango(p.mxn_minimo, p.mxn_maximo, mxn)} MXN<br />
              <b>Dólares (referencial):</b> {rango(p.usd_minimo, p.usd_maximo, usd)}
            </p>
          </details>
        ))}
      </div>
      <div className="card">
        <h2>Calculadora de UMAs</h2>
        <input inputMode="decimal" value={umas} onChange={(e) => setUmas(e.target.value)} placeholder="Número de UMAs" />
        {t && n > 0 && (
          <p>
            {n} UMA = <b>{mxn(n * t.valor_uma_vigente)} MXN</b><br />
            <span className="note" style={{ margin: 0 }}>≈ {usd((n * t.valor_uma_vigente) / t.tipo_cambio_usd_referencial)} (referencial)</span>
          </p>
        )}
        <p className="note">Si la infracción causa un accidente, el reglamento prevé aplicar la multa al 200%. El monto final lo determina la autoridad con el tabulador vigente.</p>
      </div>
    </>
  );
}

// Directorio de direcciones de la Secretaría
export function Directorio() {
  const l = useQuery(api.institucional.departamentosListar);
  if (!l || l.length === 0) return null;
  return (
    <div className="card">
      <h2>🏛️ Direcciones de la Secretaría</h2>
      {l.map((d) => (
        <details key={d._id}><summary>{d.nombre}</summary><p>{d.descripcion}</p></details>
      ))}
    </div>
  );
}

// Buzón de transparencia: la ciudadanía califica el trato
export function Evaluar() {
  const enviar = useMutation(api.operativo.evaluar);
  const [ref, setRef] = useState("");
  const [e, setE] = useState(0);
  const [c, setC] = useState("");
  const [msg, setMsg] = useState("");
  return (
    <div className="card">
      <h2>⭐ Califica el trato recibido</h2>
      <input value={ref} onChange={(x) => setRef(x.target.value)} placeholder="Folio de tu boleta o número de placa del oficial" />
      <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} className="chip" style={{ fontSize: 22, padding: "2px 10px", color: n <= e ? "#d98e04" : undefined }} onClick={() => setE(n)} aria-label={n + " estrellas"}>{n <= e ? "★" : "☆"}</button>
        ))}
      </div>
      <textarea rows={2} value={c} onChange={(x) => setC(x.target.value)} placeholder="Comentarios o sugerencias (opcional)" />
      <button className="btn" onClick={async () => { try { await enviar({ referencia: ref, estrellas: e, comentario: c || undefined }); setMsg("Gracias por tu opinión."); setRef(""); setE(0); setC(""); } catch { setMsg("Escribe la referencia y elige las estrellas."); } }}>Enviar calificación</button>
      <p className="note">{msg}</p>
    </div>
  );
}
