import { useEffect, useRef, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

// Leaflet se carga desde CDN solo en el navegador (el servidor no tiene "window").
type LGroup = { clearLayers(): void };
type LMap = { setView(c: [number, number], z: number): LMap; remove(): void };
type LMarker = { bindPopup(html: string): LMarker; addTo(g: LGroup): LMarker };
type LLib = {
  map(el: HTMLElement): LMap;
  tileLayer(url: string, o: { attribution: string }): { addTo(m: LMap): unknown };
  layerGroup(): { addTo(m: LMap): LGroup };
  divIcon(o: object): unknown;
  marker(p: [number, number], o: { icon: unknown }): LMarker;
};

const CENTRO: [number, number] = [26.0924, -98.2831]; // Centro de Reynosa
const V = "1.9.4";

function cargarLeaflet(): Promise<LLib> {
  const w = window as unknown as { L?: LLib };
  if (w.L) return Promise.resolve(w.L);
  return new Promise((ok, fallo) => {
    const css = document.createElement("link");
    css.rel = "stylesheet";
    css.href = `https://unpkg.com/leaflet@${V}/dist/leaflet.css`;
    document.head.appendChild(css);
    const js = document.createElement("script");
    js.src = `https://unpkg.com/leaflet@${V}/dist/leaflet.js`;
    js.onload = () => (w.L ? ok(w.L) : fallo(new Error("Leaflet no cargó")));
    js.onerror = () => fallo(new Error("Leaflet no cargó"));
    document.head.appendChild(js);
  });
}

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export default function MapaReportes({ publico = false }: { publico?: boolean }) {
  const privado = useQuery(api.reportes.mapa, publico ? "skip" : {});
  const abierto = useQuery(api.reportes.mapaPublico, publico ? {} : "skip");
  const puntos = publico ? abierto : privado;
  const el = useRef<HTMLDivElement>(null);
  const mapa = useRef<{ map: LMap; grupo: LGroup; L: LLib } | null>(null);
  const [listo, setListo] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    let vivo = true;
    cargarLeaflet()
      .then((L) => {
        if (!vivo || !el.current) return;
        const map = L.map(el.current).setView(CENTRO, 13);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>',
        }).addTo(map);
        mapa.current = { map, grupo: L.layerGroup().addTo(map), L };
        setListo(true);
      })
      .catch(() => setError(true));
    return () => {
      vivo = false;
      mapa.current?.map.remove();
      mapa.current = null;
      setListo(false);
    };
  }, []);

  useEffect(() => {
    const m = mapa.current;
    if (!listo || !m || !puntos) return;
    m.grupo.clearLayers();
    for (const p of puntos) {
      const nuevo = p.estatus.toLowerCase() === "recibido";
      const color = nuevo ? "#a52934" : "#d98e04";
      const icon = m.L.divIcon({
        className: "",
        html: `<div style="width:18px;height:18px;border-radius:50%;background:${color};border:3px solid #fff;box-shadow:0 0 4px rgba(0,0,0,.5)"></div>`,
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      });
      const html =
        `<div style="font-family:sans-serif"><h4 style="margin:0 0 5px;color:#002f6c">${esc(p.tipo_incidencia)}</h4>` +
        (p.descripcion ? `<p style="margin:0 0 10px;font-size:13px">${esc(p.descripcion)}</p>` : "") +
        `<span style="padding:3px 8px;border-radius:20px;font-size:11px;background:${nuevo ? "#ffccd5" : "#ffe3b3"};color:${nuevo ? "#ff4d6d" : "#b77c00"}">${esc(p.estatus.toUpperCase())}</span></div>`;
      m.L.marker([p.latitud as number, p.longitud as number], { icon }).bindPopup(html).addTo(m.grupo);
    }
  }, [listo, puntos]);

  return (
    <>
      <div ref={el} style={{ height: 450, width: "100%", borderRadius: 12, overflow: "hidden" }} />
      {error && <p className="note">No se pudo cargar el mapa. Revisa tu conexión.</p>}
      {!error && puntos && puntos.length === 0 && <p className="note">No hay reportes abiertos con ubicación.</p>}
    </>
  );
}
