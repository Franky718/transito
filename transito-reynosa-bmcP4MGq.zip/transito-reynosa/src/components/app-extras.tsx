import { useEffect, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { ARTICULOS, FUENTE_REGLAMENTO } from "@/lib/reglamento";

export function Reglamento() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("Todos");
  const db = useQuery(api.reglamento.listar);
  const base = db && db.length > 0 ? db : ARTICULOS;
  const cats = ["Todos", ...Array.from(new Set(base.map((a) => a.cap)))];
  const t = q.trim().toLowerCase();
  const lista = base.filter(
    (a) =>
      (cat === "Todos" || a.cap === cat) &&
      (!t || (a.art + " " + a.t + " " + a.d).toLowerCase().includes(t) || t === "art " + a.art.toLowerCase()),
  );
  return (
    <div className="card">
      <h2>📖 Reglamento de Tránsito y Vialidad</h2>
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar: velocidad, cochera, 63, alcohol…" />
      <div className="chips">
        {cats.map((c) => (
          <button key={c} className={"chip" + (c === cat ? " on" : "")} onClick={() => setCat(c)}>{c}</button>
        ))}
      </div>
      <p className="note" style={{ marginTop: 0 }}>{lista.length} de {base.length} temas</p>
      {lista.length === 0 && <p className="note">Sin resultados.</p>}
      {lista.map((a) => (
        <details key={a.art + a.t}>
          <summary>Art. {a.art} · {a.t}<span className="tag">{a.cap}</span></summary>
          <p>{a.d}</p>
        </details>
      ))}
      <p className="note">{FUENTE_REGLAMENTO}</p>
      <p className="note"><a href="https://www.reynosa.gob.mx/transparencia/reglamentos/municipales/Reglamento_Transito.pdf" target="_blank" rel="noreferrer">Ver el texto oficial completo (PDF, con tabulador de infracciones)</a></p>
    </div>
  );
}

type PromptEvent = Event & { prompt(): Promise<void> };

export function Instalar() {
  const [ev, setEv] = useState<PromptEvent | null>(null);
  const [instalada, setInstalada] = useState(false);
  const [ayuda, setAyuda] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
    setIos(/iphone|ipad|ipod/i.test(navigator.userAgent));
    setInstalada(window.matchMedia("(display-mode: standalone)").matches);
    const h = (e: Event) => {
      e.preventDefault();
      setEv(e as PromptEvent);
    };
    window.addEventListener("beforeinstallprompt", h);
    const ok = () => setInstalada(true);
    window.addEventListener("appinstalled", ok);
    return () => {
      window.removeEventListener("beforeinstallprompt", h);
      window.removeEventListener("appinstalled", ok);
    };
  }, []);

  if (instalada) return null;
  return (
    <div className="card">
      <div className="row" style={{ border: 0, padding: 0 }}>
        <div><b>📲 Instala la app en tu celular</b><br /><span className="note" style={{ margin: 0 }}>Se abre como una app, con su ícono en tu pantalla.</span></div>
        <button className="btn sm" style={{ marginBottom: 0 }} onClick={() => (ev ? ev.prompt() : setAyuda(true))}>Instalar</button>
      </div>
      {ayuda && (
        <p className="note">
          {ios
            ? "En iPhone: abre esta página en Safari, toca el botón Compartir y elige “Agregar a pantalla de inicio”."
            : "En Android: abre el menú del navegador (⋮) y elige “Instalar aplicación” o “Agregar a pantalla de inicio”."}
        </p>
      )}
    </div>
  );
}
