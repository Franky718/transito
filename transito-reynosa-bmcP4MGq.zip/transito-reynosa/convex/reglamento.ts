import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { verificar } from "./acceso"

// Lectura pública: lo que ve la ciudadanía
export const listar = query({
  args: {},
  handler: async (ctx) => {
    const l = await ctx.db.query("articulos").take(500)
    return l.sort((a, b) => a.orden - b.orden).map((x) => ({ _id: x._id, art: x.art, cap: x.cap, t: x.t, d: x.d }))
  },
})

export const guardar = mutation({
  args: { clave: v.string(), id: v.optional(v.id("articulos")), art: v.string(), cap: v.string(), t: v.string(), d: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const art = a.art.trim().slice(0, 20), cap = a.cap.trim().slice(0, 60), t = a.t.trim().slice(0, 150), d = a.d.trim().slice(0, 2000)
    if (!art || !cap || !t || !d) throw new Error("Datos incompletos")
    if (a.id) {
      await ctx.db.patch(a.id, { art, cap, t, d })
    } else {
      const todos = await ctx.db.query("articulos").take(500)
      await ctx.db.insert("articulos", { art, cap, t, d, orden: todos.reduce((m, x) => Math.max(m, x.orden), 0) + 1 })
    }
  },
})

export const borrar = mutation({
  args: { clave: v.string(), id: v.id("articulos") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    await ctx.db.delete(a.id)
  },
})

// Carga inicial desde los artículos base de la app (solo si está vacío)
export const sembrar = mutation({
  args: { clave: v.string(), articulos: v.array(v.object({ art: v.string(), cap: v.string(), t: v.string(), d: v.string() })) },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const ya = await ctx.db.query("articulos").first()
    if (ya) return 0
    let i = 0
    for (const x of a.articulos.slice(0, 300)) await ctx.db.insert("articulos", { ...x, orden: ++i })
    return i
  },
})
