import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { quien, sha256, verificar } from "./acceso"

const ALFABETO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
function nuevaClave() {
  const b = new Uint8Array(10)
  crypto.getRandomValues(b)
  return Array.from(b).map((x) => ALFABETO[x % ALFABETO.length]).join("")
}

// Quién soy con esta clave (null si no es válida)
export const yo = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => await quien(ctx, a.clave),
})

export const listar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const l = await ctx.db.query("oficiales").take(300)
    return l.map((o) => ({ _id: o._id, nombre: o.nombre, numero: o.numero, rol: o.rol, activo: o.activo }))
  },
})

// Crea al oficial y devuelve su clave UNA sola vez (solo se guarda su huella)
export const crear = mutation({
  args: { clave: v.string(), nombre: v.string(), numero: v.string(), rol: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const nombre = a.nombre.trim().slice(0, 80)
    const numero = a.numero.trim().toUpperCase().slice(0, 30)
    if (!nombre || !numero) throw new Error("Datos incompletos")
    if (numero === "JEFATURA") throw new Error("Número reservado")
    const ya = await ctx.db.query("oficiales").withIndex("by_numero", (q) => q.eq("numero", numero)).first()
    if (ya) throw new Error("Ya existe un oficial con ese número")
    const clavePersonal = nuevaClave()
    await ctx.db.insert("oficiales", {
      nombre, numero, rol: a.rol === "admin" ? "admin" : "oficial", claveHash: await sha256(clavePersonal), activo: true,
    })
    return { clave: clavePersonal }
  },
})

export const regenerar = mutation({
  args: { clave: v.string(), id: v.id("oficiales") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const clavePersonal = nuevaClave()
    await ctx.db.patch(a.id, { claveHash: await sha256(clavePersonal) })
    return { clave: clavePersonal }
  },
})

export const activar = mutation({
  args: { clave: v.string(), id: v.id("oficiales"), activo: v.boolean() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    await ctx.db.patch(a.id, { activo: a.activo })
  },
})
