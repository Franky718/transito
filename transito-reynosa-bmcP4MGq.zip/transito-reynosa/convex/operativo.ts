import { mutation, query } from "./_generated/server"
import type { MutationCtx, QueryCtx } from "./_generated/server"
import { v } from "convex/values"
import { sha256, verificar } from "./acceso"

const placaN = (p: string) => p.trim().toUpperCase().replace(/\s+/g, "")
const folio = (p: string) => p + Math.floor(100000 + Math.random() * 900000)
const cut = (s: string, n: number) => s.trim().slice(0, n)
const opt = (s: string | undefined, n: number) => (s && s.trim() ? cut(s, n) : undefined)
const TURNOS = ["Matutino", "Vespertino", "Nocturno", "Guardia especial"]
const COM = { lat: 26.0925, lng: -98.2852, radio: 500 }

// Sello de integridad: cada ingreso incluye el sello del anterior (cadena de hashes SHA-256).
// Si alguien altera un dato sellado, la verificación detecta dónde se rompe la cadena.
const contenidoSello = (c: { selloPrevio?: string; folio: string; placa: string; empresaGrua: string; motivo: string; oficialId: string; selloFecha?: number }) =>
  [c.selloPrevio ?? "", c.folio, c.placa, c.empresaGrua, c.motivo, c.oficialId, c.selloFecha ?? 0].join("|")

async function cfg(ctx: QueryCtx | MutationCtx, k: string, def: number) {
  const c = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", k)).first()
  return c ? c.valor : def
}
async function fijar(ctx: MutationCtx, k: string, valor: number) {
  const c = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", k)).first()
  if (c) await ctx.db.patch(c._id, { valor })
  else await ctx.db.insert("config", { clave: k, valor })
}
function metros(a1: number, o1: number, a2: number, o2: number) {
  const R = 6371000, r = Math.PI / 180
  const dA = (a2 - a1) * r, dO = (o2 - o1) * r
  const h = Math.sin(dA / 2) ** 2 + Math.cos(a1 * r) * Math.cos(a2 * r) * Math.sin(dO / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(h))
}

// ---------- Corralón ----------
export const fotoSubirUrl = mutation({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.storage.generateUploadUrl()
  },
})
export const corralonIngreso = mutation({
  args: {
    clave: v.string(), empresaGrua: v.string(), placa: v.string(), estadoPlaca: v.string(),
    marca: v.optional(v.string()), linea: v.optional(v.string()), modelo: v.optional(v.number()),
    color: v.optional(v.string()), vin: v.optional(v.string()), motivo: v.string(),
    checklist: v.array(v.string()), observaciones: v.optional(v.string()),
    fotos: v.optional(v.array(v.id("_storage"))),
  },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    const placa = placaN(a.placa)
    if (!placa || !a.empresaGrua.trim() || !a.motivo.trim()) throw new Error("Datos incompletos")
    const f = folio("GR-")
    const doc = {
      folio: f, empresaGrua: cut(a.empresaGrua, 100), placa, estadoPlaca: cut(a.estadoPlaca, 50),
      marca: opt(a.marca, 50), linea: opt(a.linea, 50), modelo: a.modelo, color: opt(a.color, 30), vin: opt(a.vin, 50),
      motivo: cut(a.motivo, 100), checklist: a.checklist.slice(0, 20).map((x) => cut(x, 60)),
      observaciones: opt(a.observaciones, 500), estatus: "En resguardo", oficialId: yo.id,
      fotos: a.fotos?.slice(0, 8),
    }
    const previo = (await ctx.db.query("corralon").order("desc").take(50)).find((x) => x.sello)
    const selloPrevio = previo?.sello ?? "GENESIS"
    const selloFecha = Date.now()
    const sello = await sha256(contenidoSello({ ...doc, selloPrevio, selloFecha }))
    await ctx.db.insert("corralon", { ...doc, selloPrevio, selloFecha, sello })
    const m = await ctx.db.query("multas").withIndex("by_placa", (q) => q.eq("placa", placa)).take(100)
    return { folio: f, multasPendientes: m.filter((x) => !x.pagada).length }
  },
})
export const corralonListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const filas = await ctx.db.query("corralon").order("desc").take(200)
    return await Promise.all(
      filas.map(async (c) => ({
        ...c,
        fotoUrls: (await Promise.all((c.fotos ?? []).map((id) => ctx.storage.getUrl(id)))).filter((u): u is string => !!u),
      })),
    )
  },
})
export const corralonVerificarSellos = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const sellados = (await ctx.db.query("corralon").order("asc").take(5000)).filter((x) => x.sello)
    let esperado = "GENESIS"
    for (const c of sellados) {
      const calculado = await sha256(contenidoSello(c))
      if (c.selloPrevio !== esperado || c.sello !== calculado) return { total: sellados.length, integra: false, rotoEn: c.folio }
      esperado = c.sello!
    }
    return { total: sellados.length, integra: true, rotoEn: null as string | null }
  },
})
export const corralonEstatus = mutation({
  args: { clave: v.string(), id: v.id("corralon"), estatus: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    if (!["En resguardo", "En proceso de liberación", "Liberado"].includes(a.estatus)) throw new Error("Estatus no válido")
    const c = await ctx.db.get(a.id)
    if (!c) throw new Error("No existe")
    if (a.estatus === "Liberado") {
      const m = await ctx.db.query("multas").withIndex("by_placa", (q) => q.eq("placa", c.placa)).take(100)
      if (m.some((x) => !x.pagada)) throw new Error("Multas pendientes")
    }
    await ctx.db.patch(a.id, { estatus: a.estatus })
  },
})

// ---------- Antecedentes por placa ----------
export const antecedentes = query({
  args: { clave: v.string(), placa: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const placa = placaN(a.placa)
    if (!placa) return null
    const mu = await ctx.db.query("multas").withIndex("by_placa", (q) => q.eq("placa", placa)).take(100)
    const co = await ctx.db.query("corralon").withIndex("by_placa", (q) => q.eq("placa", placa)).take(50)
    const roja = co.some((c) => c.estatus !== "Liberado")
    const naranja = mu.some((m) => !m.pagada)
    return {
      placa,
      nivel: roja ? "roja" : naranja ? "naranja" : "verde",
      multas: mu.map((m) => ({ folio: m.folio, motivo: m.motivo, monto: m.monto, montoUmas: m.montoUmas, pagada: m.pagada, fecha: m._creationTime })),
      corralon: co.map((c) => ({ folio: c.folio, estatus: c.estatus, motivo: c.motivo, fecha: c._creationTime })),
    }
  },
})

// ---------- Checador digital con geocerca ----------
export const asistenciaConfig = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return { lat: await cfg(ctx, "com_lat", COM.lat), lng: await cfg(ctx, "com_lng", COM.lng), radio: await cfg(ctx, "com_radio", COM.radio) }
  },
})
export const asistenciaConfigurar = mutation({
  args: { clave: v.string(), lat: v.number(), lng: v.number(), radio: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    if (a.radio < 50 || a.radio > 5000) throw new Error("Radio no válido")
    await fijar(ctx, "com_lat", a.lat); await fijar(ctx, "com_lng", a.lng); await fijar(ctx, "com_radio", a.radio)
  },
})
export const asistenciaChecar = mutation({
  args: { clave: v.string(), turno: v.string(), tipo: v.string(), latitud: v.number(), longitud: v.number() },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    if (!TURNOS.includes(a.turno) || !["ENTRADA", "SALIDA"].includes(a.tipo)) throw new Error("Datos no válidos")
    const lat = await cfg(ctx, "com_lat", COM.lat), lng = await cfg(ctx, "com_lng", COM.lng), radio = await cfg(ctx, "com_radio", COM.radio)
    const d = Math.round(metros(a.latitud, a.longitud, lat, lng))
    if (d > radio) throw new Error("Fuera del perímetro: " + d + " m")
    await ctx.db.insert("asistencia", { oficialId: yo.id, nombre: yo.nombre, turno: a.turno, tipo: a.tipo, latitud: a.latitud, longitud: a.longitud, distanciaM: d })
    return { distanciaM: d }
  },
})
export const asistenciaListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    const todos = await ctx.db.query("asistencia").order("desc").take(300)
    return (yo.rol === "admin" ? todos : todos.filter((x) => x.oficialId === yo.id)).slice(0, 100)
  },
})

// ---------- Botón SOS ----------
export const sosEnviar = mutation({
  args: { clave: v.string(), latitud: v.optional(v.number()), longitud: v.optional(v.number()), nota: v.optional(v.string()) },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    await ctx.db.insert("sos", { oficialId: yo.id, nombre: yo.nombre, latitud: a.latitud, longitud: a.longitud, nota: opt(a.nota, 200), atendida: false })
  },
})
export const sosActivas = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const l = await ctx.db.query("sos").order("desc").take(50)
    return l.filter((x) => !x.atendida)
  },
})
export const sosAtender = mutation({
  args: { clave: v.string(), id: v.id("sos") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    await ctx.db.patch(a.id, { atendida: true })
  },
})

// ---------- Flotilla ----------
export const unidadesListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("unidades").take(200)
  },
})
export const unidadCrear = mutation({
  args: { clave: v.string(), numero: v.string(), tipo: v.string(), kilometraje: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const numero = cut(a.numero, 20).toUpperCase()
    if (!numero) throw new Error("Falta el número económico")
    const ya = await ctx.db.query("unidades").withIndex("by_numero", (q) => q.eq("numero", numero)).first()
    if (ya) throw new Error("Ya existe")
    await ctx.db.insert("unidades", { numero, tipo: cut(a.tipo, 30), kilometraje: Math.max(0, a.kilometraje), estado: "En servicio" })
  },
})
export const unidadRegistrar = mutation({
  args: { clave: v.string(), numero: v.string(), tipo: v.string(), descripcion: v.string(), litros: v.optional(v.number()), monto: v.optional(v.number()), km: v.optional(v.number()) },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    const u = await ctx.db.query("unidades").withIndex("by_numero", (q) => q.eq("numero", a.numero)).first()
    if (!u) throw new Error("Unidad no encontrada")
    await ctx.db.insert("unidadRegistros", { numero: u.numero, tipo: cut(a.tipo, 30), descripcion: cut(a.descripcion, 300), litros: a.litros, monto: a.monto, km: a.km, oficialId: yo.id })
    if (a.km !== undefined && a.km > u.kilometraje) await ctx.db.patch(u._id, { kilometraje: a.km })
  },
})
export const unidadRegistrosListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("unidadRegistros").order("desc").take(100)
  },
})

// ---------- Buzón de transparencia (ciudadanía califica) ----------
export const evaluar = mutation({
  args: { referencia: v.string(), estrellas: v.number(), comentario: v.optional(v.string()) },
  handler: async (ctx, a) => {
    const e = Math.round(a.estrellas)
    const ref = cut(a.referencia, 40)
    if (e < 1 || e > 5 || !ref) throw new Error("Datos no válidos")
    await ctx.db.insert("evaluaciones", { referencia: ref, estrellas: e, comentario: opt(a.comentario, 300) })
  },
})
export const evaluacionesResumen = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const todas = await ctx.db.query("evaluaciones").order("desc").take(500)
    const prom = todas.length ? todas.reduce((t, x) => t + x.estrellas, 0) / todas.length : 0
    return { total: todas.length, promedio: Math.round(prom * 100) / 100, recientes: todas.slice(0, 30).map((x) => ({ referencia: x.referencia, estrellas: x.estrellas, comentario: x.comentario, fecha: x._creationTime })) }
  },
})

// ---------- Mapa de calor ----------
export const puntosCalor = query({
  args: { clave: v.string(), dias: v.number(), capa: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const desde = Date.now() - Math.max(1, Math.min(365, a.dias)) * 86400000
    const pts: number[][] = []
    if (a.capa !== "accidentes") {
      for (const r of await ctx.db.query("reportes").order("desc").take(2000)) {
        if (r._creationTime >= desde && r.latitud !== undefined && r.longitud !== undefined) pts.push([r.latitud, r.longitud, 1])
      }
    }
    if (a.capa !== "reportes") {
      for (const x of await ctx.db.query("accidentes").order("desc").take(2000)) {
        if (x._creationTime >= desde && x.latitud !== undefined && x.longitud !== undefined) pts.push([x.latitud, x.longitud, 1 + x.lesionados + 2 * x.fallecidos])
      }
    }
    return pts
  },
})
