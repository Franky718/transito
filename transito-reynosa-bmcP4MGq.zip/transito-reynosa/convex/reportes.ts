import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { verificar } from "./acceso"

const ESTATUS = ["Recibido", "En atención", "Atendido", "Rechazado"]

// ---- Ciudadanía ----
export const crear = mutation({
  args: { tipo: v.string(), ubicacion: v.string(), descripcion: v.string(), latitud: v.optional(v.number()), longitud: v.optional(v.number()) },
  handler: async (ctx, a) => {
    const ubicacion = a.ubicacion.trim().slice(0, 200)
    if (!ubicacion) throw new Error("Falta la ubicación")
    const folio = "REY-" + Math.floor(100000 + Math.random() * 900000)
    await ctx.db.insert("reportes", {
      folio,
      tipo: a.tipo.slice(0, 60),
      ubicacion,
      descripcion: a.descripcion.trim().slice(0, 500),
      estatus: "Recibido",
      latitud: a.latitud,
      longitud: a.longitud,
    })
    return folio
  },
})

export const porFolios = query({
  args: { folios: v.array(v.string()) },
  handler: async (ctx, a) => {
    const out: { folio: string; tipo: string; ubicacion: string; descripcion: string; estatus: string }[] = []
    for (const f of a.folios.slice(0, 50)) {
      const r = await ctx.db.query("reportes").withIndex("by_folio", (q) => q.eq("folio", f)).first()
      if (r) out.push({ folio: r.folio, tipo: r.tipo, ubicacion: r.ubicacion, descripcion: r.descripcion, estatus: r.estatus })
    }
    return out
  },
})

export const estadisticas = query({
  args: {},
  handler: async (ctx) => {
    const todos = await ctx.db.query("reportes").collect()
    return { total: todos.length, atendidos: todos.filter((r) => r.estatus === "Atendido").length }
  },
})

// ---- Personal de la Secretaría ----
export const listarAdmin = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("reportes").order("desc").take(200)
  },
})

export const cambiarEstatus = mutation({
  args: { clave: v.string(), id: v.id("reportes"), estatus: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    if (!ESTATUS.includes(a.estatus)) throw new Error("Estatus no válido")
    await ctx.db.patch(a.id, { estatus: a.estatus })
  },
})

// Reportes abiertos con coordenadas, para el mapa
export const mapa = query({
  args: {},
  handler: async (ctx) => {
    const todos = await ctx.db.query("reportes").order("desc").take(500)
    return todos
      .filter((r) => r.estatus !== "Atendido" && r.estatus !== "Rechazado" && r.latitud !== undefined && r.longitud !== undefined)
      .map((r) => ({ id: r._id, tipo_incidencia: r.tipo, descripcion: r.descripcion, latitud: r.latitud, longitud: r.longitud, estatus: r.estatus }))
  },
})

// Versión pública del mapa: sin el texto que escribió la persona
export const mapaPublico = query({
  args: {},
  handler: async (ctx) => {
    const todos = await ctx.db.query("reportes").order("desc").take(500)
    return todos
      .filter((r) => r.estatus !== "Atendido" && r.estatus !== "Rechazado" && r.latitud !== undefined && r.longitud !== undefined)
      .map((r) => ({ id: r._id, tipo_incidencia: r.tipo, descripcion: "", latitud: r.latitud, longitud: r.longitud, estatus: r.estatus }))
  },
})
