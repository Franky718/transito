import type { MutationCtx, QueryCtx } from "./_generated/server"

export type Quien = { id: string; nombre: string; rol: "admin" | "oficial" }

export async function sha256(t: string) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t))
  return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join("")
}

// Identifica a quien presenta la clave: clave maestra (Jefatura) o clave personal de un oficial activo.
export async function quien(ctx: QueryCtx | MutationCtx, clave: string): Promise<Quien | null> {
  const c = clave.trim()
  if (!c) return null
  const maestra = process.env.ADMIN_KEY
  if (maestra && c === maestra) return { id: "JEFATURA", nombre: "Jefatura (clave maestra)", rol: "admin" }
  const h = await sha256(c)
  const o = await ctx.db.query("oficiales").withIndex("by_hash", (q) => q.eq("claveHash", h)).first()
  return o && o.activo ? { id: o.numero, nombre: o.nombre, rol: o.rol === "admin" ? "admin" : "oficial" } : null
}

export async function verificar(ctx: QueryCtx | MutationCtx, clave: string, soloAdmin = false): Promise<Quien> {
  const q = await quien(ctx, clave)
  if (!q) throw new Error("Clave de personal incorrecta")
  if (soloAdmin && q.rol !== "admin") throw new Error("Permiso insuficiente: solo administración")
  return q
}
