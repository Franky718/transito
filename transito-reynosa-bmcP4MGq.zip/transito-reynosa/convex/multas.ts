import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { verificar } from "./acceso"

const norm = (p: string) => p.trim().toUpperCase().replace(/\s+/g, "")

// ---- Ciudadanía: solo consulta ----
export const consultar = query({
  args: { placa: v.string() },
  handler: async (ctx, a) => {
    const placa = norm(a.placa)
    if (!placa) return []
    const l = await ctx.db.query("multas").withIndex("by_placa", (q) => q.eq("placa", placa)).take(50)
    return l.map((m) => ({ folio: m.folio, motivo: m.motivo, monto: m.monto, montoUmas: m.montoUmas, pagada: m.pagada }))
  },
})

// Consulta ciudadana por placa: multas y estatus de corralón. Sin datos personales ni de propietario.
export const consultarVehiculo = query({
  args: { placa: v.string() },
  handler: async (ctx, a) => {
    const placa = norm(a.placa)
    if (!placa || placa.length > 12) return null
    const mu = await ctx.db.query("multas").withIndex("by_placa", (q) => q.eq("placa", placa)).take(50)
    const co = await ctx.db.query("corralon").withIndex("by_placa", (q) => q.eq("placa", placa)).order("desc").take(20)
    const enCorralon = co.find((c) => c.estatus !== "Liberado")
    const pend = mu.filter((m) => !m.pagada)
    const r2 = (n: number) => Math.round(n * 100) / 100
    return {
      placa,
      estatus_corralon: enCorralon ? { folio: enCorralon.folio, estatus: enCorralon.estatus } : null,
      multas_pendientes: pend.length,
      total_a_pagar_mxn: r2(pend.reduce((t, m) => t + m.monto, 0)),
      total_a_pagar_umas: r2(pend.reduce((t, m) => t + (m.montoUmas ?? 0), 0)),
      multas: mu.map((m) => ({ folio: m.folio, motivo: m.motivo, monto: m.monto, montoUmas: m.montoUmas, pagada: m.pagada })),
    }
  },
})

// ---- Personal de la Secretaría ----
export const listarAdmin = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("multas").order("desc").take(200)
  },
})

export const agregar = mutation({
  args: { clave: v.string(), placa: v.string(), motivo: v.string(), monto: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const placa = norm(a.placa)
    if (!placa || !a.motivo.trim() || !(a.monto > 0)) throw new Error("Datos incompletos")
    const folio = "M-" + Math.floor(100000 + Math.random() * 900000)
    await ctx.db.insert("multas", { folio, placa, motivo: a.motivo.trim().slice(0, 200), monto: a.monto, pagada: false })
    return folio
  },
})

export const marcarPagada = mutation({
  args: { clave: v.string(), id: v.id("multas") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    await ctx.db.patch(a.id, { pagada: true })
  },
})

// Registro con cálculo en el servidor: UMAs del catálogo x valor vigente de la UMA
export const registrar = mutation({
  args: {
    clave: v.string(),
    oficialId: v.optional(v.string()),
    causoAccidente: v.optional(v.boolean()),
    placa: v.string(),
    tipoPlaca: v.string(),
    infraccionId: v.id("infracciones"),
    observaciones: v.optional(v.string()),
  },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    const inf = await ctx.db.get(a.infraccionId)
    if (!inf) throw new Error("Infracción no válida en el reglamento")
    if (inf.verificada === false) throw new Error("Infracción sin verificar: confirma el monto con el tabulador oficial")
    const placa = norm(a.placa)
    if (!placa) throw new Error("Falta la placa")
    const cfg = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", "uma")).first()
    const uma = cfg?.valor ?? 117.31
    const montoUmas = inf.umasMin * (a.causoAccidente ? 2 : 1) // Si causa un accidente se aplica al 200%
    const monto = Math.round(montoUmas * uma * 100) / 100
    const folio = "M-" + Math.floor(100000 + Math.random() * 900000)
    await ctx.db.insert("multas", {
      folio, placa, motivo: inf.descripcion, monto, pagada: false,
      tipoPlaca: a.tipoPlaca.slice(0, 40), infraccionId: a.infraccionId,
      observaciones: a.observaciones?.slice(0, 500), oficialId: yo.id, montoUmas,
    })
    return { folio, monto_umas: montoUmas, monto_mxn: monto, placa }
  },
})
