import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { verificar } from "./acceso"

const folio = (p: string) => p + Math.floor(100000 + Math.random() * 900000)
const cut = (s: string, n: number) => s.trim().slice(0, n)

// ---- Resumen del turno ----
export const resumen = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    const rep = await ctx.db.query("reportes").collect()
    const mul = await ctx.db.query("multas").collect()
    const acc = await ctx.db.query("accidentes").collect()
    const ops = await ctx.db.query("operativos").collect()
    return {
      reportesAbiertos: rep.filter((r) => r.estatus === "Recibido" || r.estatus === "En atención").length,
      multasPendientes: mul.filter((m) => !m.pagada).length,
      montoPendiente: mul.filter((m) => !m.pagada).reduce((t, m) => t + m.monto, 0),
      accidentes: acc.length,
      lesionados: acc.reduce((t, x) => t + x.lesionados, 0),
      fallecidos: acc.reduce((t, x) => t + x.fallecidos, 0),
      operativosProgramados: ops.filter((o) => o.estado === "Programado").length,
    }
  },
})

// ---- Accidentes (partes de hechos de tránsito) ----
export const accidentesListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("accidentes").order("desc").take(200)
  },
})
export const accidentesCrear = mutation({
  args: {
    clave: v.string(), tipo: v.string(), ubicacion: v.string(), lesionados: v.number(), fallecidos: v.number(),
    vehiculos: v.number(), descripcion: v.string(), oficialId: v.optional(v.string()),
    latitud: v.optional(v.number()), longitud: v.optional(v.number()),
  },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    if (!a.ubicacion.trim()) throw new Error("Datos incompletos")
    const f = folio("AC-")
    await ctx.db.insert("accidentes", {
      folio: f, tipo: cut(a.tipo, 40), ubicacion: cut(a.ubicacion, 200), lesionados: Math.max(0, a.lesionados),
      fallecidos: Math.max(0, a.fallecidos), vehiculos: Math.max(0, a.vehiculos), descripcion: cut(a.descripcion, 800),
      oficialId: yo.id, estatus: "Abierto", latitud: a.latitud, longitud: a.longitud,
    })
    return f
  },
})
export const accidentesEstatus = mutation({
  args: { clave: v.string(), id: v.id("accidentes"), estatus: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    if (!["Abierto", "Convenio", "Turnado al MP", "Cerrado"].includes(a.estatus)) throw new Error("Estatus no válido")
    await ctx.db.patch(a.id, { estatus: a.estatus })
  },
})

// ---- Operativos ----
export const operativosListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("operativos").order("desc").take(200)
  },
})
export const operativosCrear = mutation({
  args: { clave: v.string(), nombre: v.string(), tipo: v.string(), ubicacion: v.string(), fecha: v.string(), hora: v.string(), personal: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    if (!a.nombre.trim() || !a.ubicacion.trim() || !a.fecha) throw new Error("Datos incompletos")
    await ctx.db.insert("operativos", {
      nombre: cut(a.nombre, 100), tipo: cut(a.tipo, 40), ubicacion: cut(a.ubicacion, 200), fecha: cut(a.fecha, 10),
      hora: cut(a.hora, 5), personal: Math.max(0, a.personal), estado: "Programado",
    })
  },
})
export const operativosEstado = mutation({
  args: { clave: v.string(), id: v.id("operativos"), estado: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    if (!["Programado", "Realizado", "Cancelado"].includes(a.estado)) throw new Error("Estado no válido")
    await ctx.db.patch(a.id, { estado: a.estado })
  },
})

// ---- Bitácora de turno ----
export const bitacoraListar = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave)
    return await ctx.db.query("bitacora").order("desc").take(100)
  },
})
export const bitacoraCrear = mutation({
  args: { clave: v.string(), turno: v.string(), oficialId: v.optional(v.string()), texto: v.string() },
  handler: async (ctx, a) => {
    const yo = await verificar(ctx, a.clave)
    if (!a.texto.trim()) throw new Error("Datos incompletos")
    await ctx.db.insert("bitacora", { turno: cut(a.turno, 20), oficialId: yo.id, texto: cut(a.texto, 1000) })
  },
})
