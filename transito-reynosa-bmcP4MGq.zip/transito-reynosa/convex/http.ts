import { httpRouter } from "convex/server"
import { httpAction } from "./_generated/server"
import { api } from "./_generated/api"
import type { Id } from "./_generated/dataModel"
import { auth } from "./auth"

const http = httpRouter()

auth.addHttpRoutes(http)

// Quita rastros internos (rutas y líneas de código) de los mensajes de error
const limpiar = (m: string) => (m.split("\n")[0] ?? m).replace(/^.*?Uncaught Error:\s*/, "")

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { "Content-Type": "application/json" } })

// GET /api/reportes/mapa
http.route({
  path: "/api/reportes/mapa",
  method: "GET",
  handler: httpAction(async (ctx) => json(await ctx.runQuery(api.reportes.mapaPublico, {}))),
})

// POST /api/multas/registrar  (Authorization: Bearer <clave del personal>)
http.route({
  path: "/api/multas/registrar",
  method: "POST",
  handler: httpAction(async (ctx, req) => {
    const clave = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "")
    let b: Record<string, unknown>
    try {
      b = (await req.json()) as Record<string, unknown>
    } catch {
      return json({ error: "JSON inválido" }, 400)
    }
    try {
      const multa = await ctx.runMutation(api.multas.registrar, {
        clave,
        oficialId: String(b.oficial_id ?? ""),
        placa: String(b.placa ?? ""),
        tipoPlaca: String(b.tipo_placa ?? ""),
        infraccionId: b.infraccion_id as Id<"infracciones">,
        observaciones: b.observaciones ? String(b.observaciones) : undefined,
        causoAccidente: b.causo_accidente === true,
      })
      return json({ mensaje: "Multa guardada", multa }, 201)
    } catch (e) {
      const m = limpiar(e instanceof Error ? e.message : "Error")
      return json({ error: m }, m.includes("Clave") ? 401 : m.includes("Infracción") ? 404 : 400)
    }
  }),
})

// GET /api/secretaria/departamentos
http.route({
  path: "/api/secretaria/departamentos",
  method: "GET",
  handler: httpAction(async (ctx) => {
    const d = await ctx.runQuery(api.institucional.departamentosListar, {})
    return json({ success: true, institucion: "Secretaría de Seguridad Pública, Vialidad y Tránsito - Reynosa, Tamps.", departamentos: d.map((x) => ({ id: x.clave, nombre: x.nombre, descripcion: x.descripcion })) })
  }),
})

// GET /api/ciudadano/reglamento-multas?buscar=
http.route({
  path: "/api/ciudadano/reglamento-multas",
  method: "GET",
  handler: httpAction(async (ctx, req) => {
    const buscar = new URL(req.url).searchParams.get("buscar") ?? undefined
    const t = await ctx.runQuery(api.institucional.tabulador, { buscar })
    return json({ success: true, fuente: "Secretaría de Seguridad Pública, Vialidad y Tránsito de Reynosa", ...t, total_temas: t.partidas.length })
  }),
})

// GET /api/ciudadano/consultar-vehiculo-placa?placa=
http.route({
  path: "/api/ciudadano/consultar-vehiculo-placa",
  method: "GET",
  handler: httpAction(async (ctx, req) => {
    const placa = new URL(req.url).searchParams.get("placa")
    if (!placa) return json({ success: false, mensaje: "Debe proporcionar una placa vehicular." }, 400)
    const r = await ctx.runQuery(api.multas.consultarVehiculo, { placa })
    if (!r) return json({ success: false, mensaje: "Placa no válida." }, 400)
    return json({ success: true, aviso_privacidad: "Consulta protegida: no se solicitan ni procesan datos personales como CURP.", resultado: r })
  }),
})

// GET /api/monetizacion/planes
http.route({
  path: "/api/monetizacion/planes",
  method: "GET",
  handler: httpAction(async (ctx) => json({ success: true, planes: await ctx.runQuery(api.institucional.planesPublicos, {}) })),
})

// POST /api/corralon/ingreso  (Authorization: Bearer <clave>)
http.route({
  path: "/api/corralon/ingreso",
  method: "POST",
  handler: httpAction(async (ctx, req) => {
    const clave = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "")
    let b: Record<string, unknown>
    try { b = (await req.json()) as Record<string, unknown> } catch { return json({ success: false, message: "JSON inválido" }, 400) }
    try {
      const r = await ctx.runMutation(api.operativo.corralonIngreso, {
        clave, empresaGrua: String(b.empresa_grua ?? ""), placa: String(b.placa ?? ""), estadoPlaca: String(b.estado_placa ?? ""),
        marca: b.marca ? String(b.marca) : undefined, linea: b.linea ? String(b.linea) : undefined,
        modelo: typeof b.modelo === "number" ? b.modelo : undefined, color: b.color ? String(b.color) : undefined,
        vin: b.vin ? String(b.vin) : undefined, motivo: String(b.motivo_remision ?? ""),
        checklist: Array.isArray(b.checklist_fisico) ? b.checklist_fisico.map(String) : [],
        observaciones: b.observaciones ? String(b.observaciones) : undefined,
      })
      return json({ success: true, message: "Vehículo registrado exitosamente en el corralón.", data: r }, 201)
    } catch (e) {
      const m = limpiar(e instanceof Error ? e.message : "Error")
      return json({ success: false, error: m }, m.includes("Clave") ? 401 : 400)
    }
  }),
})

// POST /api/asistencia/checar  (Authorization: Bearer <clave>)
http.route({
  path: "/api/asistencia/checar",
  method: "POST",
  handler: httpAction(async (ctx, req) => {
    const clave = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "")
    let b: Record<string, unknown>
    try { b = (await req.json()) as Record<string, unknown> } catch { return json({ success: false, message: "JSON inválido" }, 400) }
    try {
      const r = await ctx.runMutation(api.operativo.asistenciaChecar, { clave, turno: String(b.turno ?? ""), tipo: String(b.tipo_registro ?? ""), latitud: Number(b.latitud), longitud: Number(b.longitud) })
      return json({ success: true, message: "Registro de " + String(b.tipo_registro) + " exitoso.", data: r })
    } catch (e) {
      const m = limpiar(e instanceof Error ? e.message : "Error")
      return json({ success: false, message: m.includes("Fuera del perímetro") ? "Error: El elemento se encuentra fuera del perímetro autorizado." : m }, m.includes("Clave") ? 401 : 400)
    }
  }),
})

// POST /api/ia/busqueda-inteligente  (Authorization: Bearer <clave>, cuerpo: { "consulta_natural": "..." })
http.route({
  path: "/api/ia/busqueda-inteligente",
  method: "POST",
  handler: httpAction(async (ctx, req) => {
    const clave = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "")
    let b: Record<string, unknown>
    try {
      b = (await req.json()) as Record<string, unknown>
    } catch {
      return json({ success: false, message: "JSON inválido" }, 400)
    }
    if (!b.consulta_natural) return json({ success: false, message: "La consulta no puede estar vacía." }, 400)
    try {
      const r = await ctx.runAction(api.ia.buscar, { clave, consulta: String(b.consulta_natural) })
      return json({ success: true, filtros_aplicados: r.filtros, total_resultados: r.total, resultados: r.resultados, resumen_inteligente: r.resumen })
    } catch (e) {
      const m = limpiar(e instanceof Error ? e.message : "Error")
      return json({ success: false, error: m }, m.includes("Clave") ? 401 : 500)
    }
  }),
})

export default http
