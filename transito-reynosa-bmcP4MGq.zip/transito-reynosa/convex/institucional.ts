import { mutation, query } from "./_generated/server"
import type { MutationCtx, QueryCtx } from "./_generated/server"
import { v } from "convex/values"
import { verificar } from "./acceso"

const UMA_DEF = 117.31
const USD_DEF = 20 // tipo de cambio referencial, editable por Administración

async function cfg(ctx: QueryCtx | MutationCtx, k: string, def: number) {
  const c = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", k)).first()
  return c ? c.valor : def
}

// ---------- Tipo de cambio referencial ----------
export const tipoCambio = query({
  args: {},
  handler: async (ctx) => await cfg(ctx, "usd_mxn", USD_DEF),
})
export const fijarTipoCambio = mutation({
  args: { clave: v.string(), valor: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    if (!(a.valor > 0)) throw new Error("Valor no válido")
    const c = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", "usd_mxn")).first()
    if (c) await ctx.db.patch(c._id, { valor: a.valor })
    else await ctx.db.insert("config", { clave: "usd_mxn", valor: a.valor })
  },
})

// ---------- Tabulador calculado en UMAs -> MXN -> USD (público, solo partidas verificadas) ----------
export const tabulador = query({
  args: { buscar: v.optional(v.string()) },
  handler: async (ctx, a) => {
    const uma = await cfg(ctx, "uma", UMA_DEF)
    const usd = await cfg(ctx, "usd_mxn", USD_DEF)
    const t = a.buscar?.trim().toLowerCase()
    const l = (await ctx.db.query("infracciones").take(500)).filter(
      (i) => i.verificada !== false && (!t || (i.descripcion + " " + (i.articulo ?? "")).toLowerCase().includes(t)),
    )
    const r2 = (n: number) => Math.round(n * 100) / 100
    return {
      valor_uma_vigente: uma,
      tipo_cambio_usd_referencial: usd,
      partidas: l.map((i) => ({
        articulo: i.articulo ?? i.clave,
        descripcion: i.descripcion,
        umas_minimo: i.umasMin,
        umas_maximo: i.umasMax,
        mxn_minimo: r2(i.umasMin * uma),
        mxn_maximo: r2(i.umasMax * uma),
        usd_minimo: r2((i.umasMin * uma) / usd),
        usd_maximo: r2((i.umasMax * uma) / usd),
      })),
    }
  },
})

// ---------- Departamentos de la Secretaría ----------
export const departamentosListar = query({
  args: {},
  handler: async (ctx) => (await ctx.db.query("departamentos").take(100)).sort((a, b) => a.orden - b.orden),
})
export const departamentosGuardar = mutation({
  args: { clave: v.string(), id: v.optional(v.id("departamentos")), nombre: v.string(), descripcion: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const nombre = a.nombre.trim().slice(0, 120), descripcion = a.descripcion.trim().slice(0, 600)
    if (!nombre || !descripcion) throw new Error("Datos incompletos")
    if (a.id) await ctx.db.patch(a.id, { nombre, descripcion })
    else {
      const todos = await ctx.db.query("departamentos").take(100)
      await ctx.db.insert("departamentos", { clave: "dep_" + (todos.length + 1), nombre, descripcion, orden: todos.reduce((m, x) => Math.max(m, x.orden), 0) + 1 })
    }
  },
})
export const departamentosBorrar = mutation({
  args: { clave: v.string(), id: v.id("departamentos") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    await ctx.db.delete(a.id)
  },
})
export const departamentosSembrar = mutation({
  args: { clave: v.string(), lista: v.array(v.object({ clave: v.string(), nombre: v.string(), descripcion: v.string() })) },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    if (await ctx.db.query("departamentos").first()) return 0
    let i = 0
    for (const d of a.lista.slice(0, 50)) await ctx.db.insert("departamentos", { ...d, orden: ++i })
    return i
  },
})

// ---------- Licenciamiento y datos de pago del desarrollador (solo administración) ----------
// Los datos viven en variables de entorno de Convex (DEV_TITULAR, DEV_BANCO, DEV_CLABE, DEV_CORREO, DEV_TARIFA_MENSUAL, DEV_GARANTIA), nunca en el código.
export const licenciamiento = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const e = process.env
    const mensual = Number(e.DEV_TARIFA_MENSUAL) > 0 ? Number(e.DEV_TARIFA_MENSUAL) : 90000
    return {
      configurado: !!(e.DEV_TITULAR && e.DEV_BANCO && e.DEV_CLABE),
      titular: e.DEV_TITULAR ?? null,
      banco: e.DEV_BANCO ?? null,
      clabe: e.DEV_CLABE ?? null,
      correoSoporte: e.DEV_CORREO ?? null,
      garantia: e.DEV_GARANTIA ?? "1 (un) año de garantía de funcionamiento continuo 24/7, con mantenimiento, parches y soporte técnico sin costo adicional.",
      tarifaMensual: mensual,
      anual: mensual * 12,
      trienio: mensual * 36,
    }
  },
})

// ---------- Planes comerciales (monetización) ----------
export const planesPublicos = query({
  args: {},
  handler: async (ctx) => (await ctx.db.query("planes").take(100)).filter((p) => p.activo),
})
export const planesAdmin = query({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    return await ctx.db.query("planes").take(100)
  },
})
export const planesGuardar = mutation({
  args: { clave: v.string(), id: v.optional(v.id("planes")), nombre: v.string(), precioMensual: v.number(), caracteristicas: v.array(v.string()), activo: v.boolean() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const nombre = a.nombre.trim().slice(0, 100)
    if (!nombre || !(a.precioMensual >= 0)) throw new Error("Datos incompletos")
    const caracteristicas = a.caracteristicas.map((x) => x.trim().slice(0, 150)).filter(Boolean).slice(0, 20)
    if (a.id) await ctx.db.patch(a.id, { nombre, precioMensual: a.precioMensual, caracteristicas, activo: a.activo })
    else await ctx.db.insert("planes", { nombre, precioMensual: a.precioMensual, caracteristicas, activo: a.activo })
  },
})
