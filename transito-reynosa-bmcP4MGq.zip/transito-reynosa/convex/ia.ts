import { action, internalQuery } from "./_generated/server"
import { api, internal } from "./_generated/api"
import { v } from "convex/values"

type Fila = { origen: string; tipo: string; ubicacion: string; estatus: string; fecha: number }

export const datos = internalQuery({
  args: { tipo: v.optional(v.string()), zona: v.optional(v.string()), diasAtras: v.optional(v.number()) },
  handler: async (ctx, a): Promise<Fila[]> => {
    const desde = a.diasAtras ? Date.now() - a.diasAtras * 86400000 : 0
    const t = a.tipo?.toLowerCase(), z = a.zona?.toLowerCase()
    const rep = await ctx.db.query("reportes").order("desc").take(500)
    const acc = await ctx.db.query("accidentes").order("desc").take(500)
    const filas: Fila[] = [
      ...rep.map((r) => ({ origen: "Reporte ciudadano", tipo: r.tipo, ubicacion: r.ubicacion, estatus: r.estatus, fecha: r._creationTime })),
      ...acc.map((x) => ({ origen: "Accidente", tipo: x.tipo, ubicacion: x.ubicacion, estatus: x.estatus, fecha: x._creationTime })),
    ]
    return filas
      .filter((f) => f.fecha >= desde && (!t || f.tipo.toLowerCase().includes(t)) && (!z || f.ubicacion.toLowerCase().includes(z)))
      .sort((p, q) => q.fecha - p.fecha)
      .slice(0, 100)
  },
})

async function gpt(key: string, messages: { role: string; content: string }[], json: boolean): Promise<string> {
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + key },
    body: JSON.stringify({ model: "gpt-4o-mini", messages, ...(json ? { response_format: { type: "json_object" } } : {}) }),
  })
  if (!r.ok) throw new Error("Error del servicio de IA (" + r.status + ")")
  const d = (await r.json()) as { choices: { message: { content: string } }[] }
  return d.choices[0].message.content
}

// Búsqueda en lenguaje natural sobre reportes y accidentes (solo personal con clave)
export const buscar = action({
  args: { clave: v.string(), consulta: v.string() },
  handler: async (ctx, a): Promise<{ filtros: Record<string, unknown>; total: number; resultados: Fila[]; resumen: string }> => {
    const yo = await ctx.runQuery(api.oficiales.yo, { clave: a.clave })
    if (!yo) throw new Error("Clave de personal incorrecta")
    const key = process.env.OPENAI_API_KEY
    if (!key) throw new Error("Falta configurar OPENAI_API_KEY")
    const consulta = a.consulta.trim().slice(0, 300)
    if (!consulta) throw new Error("La consulta no puede estar vacía")

    // 1) Lenguaje natural -> filtros (la consulta va como mensaje de usuario, no dentro de las instrucciones)
    const crudo = await gpt(key, [
      { role: "system", content: "Eres un asistente de la Secretaría de Seguridad Pública, Vialidad y Tránsito de Reynosa. Convierte la consulta del usuario en un JSON con estos campos opcionales: tipo_incidente (texto), zona (calle o colonia), dias_atras (número). Responde solo el JSON." },
      { role: "user", content: consulta },
    ], true)
    let f: Record<string, unknown> = {}
    try { f = JSON.parse(crudo) as Record<string, unknown> } catch { f = {} }
    const tipo = typeof f.tipo_incidente === "string" ? f.tipo_incidente : undefined
    const zona = typeof f.zona === "string" ? f.zona : undefined
    const dias = typeof f.dias_atras === "number" && f.dias_atras > 0 ? Math.min(f.dias_atras, 365) : undefined

    const filas = await ctx.runQuery(internal.ia.datos, { tipo, zona, diasAtras: dias })

    // 2) Resumen. Solo se envían tipo, ubicación, estatus y fecha (sin textos libres ni datos personales)
    const resumen = filas.length
      ? await gpt(key, [
          { role: "system", content: "Redacta un resumen ejecutivo breve y claro en español para un oficial de tránsito, usando únicamente los datos dados." },
          { role: "user", content: JSON.stringify(filas.slice(0, 60).map((x) => ({ ...x, fecha: new Date(x.fecha).toISOString().slice(0, 10) }))) },
        ], false)
      : "No se encontraron registros con esos criterios."
    return { filtros: { tipo_incidente: tipo, zona, dias_atras: dias }, total: filas.length, resultados: filas, resumen }
  },
})
