/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as ResendOTP from "../ResendOTP.js";
import type * as acceso from "../acceso.js";
import type * as auth from "../auth.js";
import type * as http from "../http.js";
import type * as ia from "../ia.js";
import type * as infracciones from "../infracciones.js";
import type * as institucional from "../institucional.js";
import type * as macaly from "../macaly.js";
import type * as multas from "../multas.js";
import type * as oficiales from "../oficiales.js";
import type * as operativo from "../operativo.js";
import type * as personal from "../personal.js";
import type * as reglamento from "../reglamento.js";
import type * as reportes from "../reportes.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  ResendOTP: typeof ResendOTP;
  acceso: typeof acceso;
  auth: typeof auth;
  http: typeof http;
  ia: typeof ia;
  infracciones: typeof infracciones;
  institucional: typeof institucional;
  macaly: typeof macaly;
  multas: typeof multas;
  oficiales: typeof oficiales;
  operativo: typeof operativo;
  personal: typeof personal;
  reglamento: typeof reglamento;
  reportes: typeof reportes;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
