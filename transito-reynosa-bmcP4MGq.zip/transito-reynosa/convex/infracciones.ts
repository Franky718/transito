import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { verificar } from "./acceso"

// Catálogo público (es el reglamento)
export const listar = query({
  args: {},
  handler: async (ctx) => await ctx.db.query("infracciones").take(300),
})

export const valorUma = query({
  args: {},
  handler: async (ctx) => {
    const c = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", "uma")).first()
    return c?.valor ?? 117.31
  },
})

export const agregar = mutation({
  args: { clave: v.string(), clave_inf: v.string(), descripcion: v.string(), umasMin: v.number(), umasMax: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    if (!a.descripcion.trim() || !(a.umasMin > 0) || a.umasMax < a.umasMin) throw new Error("Datos incompletos")
    await ctx.db.insert("infracciones", { clave: a.clave_inf.trim().slice(0, 30), descripcion: a.descripcion.trim().slice(0, 200), umasMin: a.umasMin, umasMax: a.umasMax, verificada: true, fuente: "Capturada por el personal" })
  },
})

export const fijarUma = mutation({
  args: { clave: v.string(), valor: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    if (!(a.valor > 0)) throw new Error("Valor no válido")
    const c = await ctx.db.query("config").withIndex("by_clave", (q) => q.eq("clave", "uma")).first()
    if (c) await ctx.db.patch(c._id, { valor: a.valor })
    else await ctx.db.insert("config", { clave: "uma", valor: a.valor })
  },
})

export const verificarPartida = mutation({
  args: { clave: v.string(), id: v.id("infracciones") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    await ctx.db.patch(a.id, { verificada: true })
  },
})

// Partidas base tomadas del tabulador publicado. Quedan SIN VERIFICAR hasta que la Secretaría las confirme.
const BASE: [string, string, number, string][] = [
  ["11", "Peatón: no cumplir sus obligaciones", 3, "Tabulador 2009/2011 (días de salario)"],
  ["11", "Pasajeros y ocupantes: no cumplir obligaciones", 3, "Tabulador 2009/2011 (días de salario)"],
  ["12", "Utilizar zona de peatones sin autorización", 5, "Tabulador 2009/2011 (días de salario)"],
  ["29", "Transportar a un menor incorrectamente (sin asiento o silla)", 7, "Tabulador 2009/2011 (días de salario)"],
  ["30", "Falta de extintor en condiciones de uso", 6, "Tabulador 2009/2011 (días de salario)"],
  ["32", "Falta de lámparas rojas posteriores o luces de estacionamiento", 5, "Tabulador 2009/2011 (días de salario)"],
  ["63", "No ceder el paso a vehículos de emergencia", 10, "Tabulador 2009/2011 (días de salario)"],
  ["63", "Utilizar emblemas oficiales en vehículos no autorizados", 5, "Tabulador 2009/2011 (días de salario)"],
  ["63", "Exceso de velocidad (arriba del límite)", 10, "Prensa dic-2025: $1,131 (≈10 UMA de 2025)"],
  ["63", "Velocidad inmoderada", 25, "Prensa dic-2025: $2,825 (≈25 UMA de 2025)"],
]
export const sembrar = mutation({
  args: { clave: v.string() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    const ya = await ctx.db.query("infracciones").take(500)
    let n = 0
    for (const [art, d, u, f] of BASE) {
      if (ya.some((i) => i.articulo === art && i.descripcion === d)) continue
      await ctx.db.insert("infracciones", { clave: "Art. " + art, articulo: art, descripcion: d, umasMin: u, umasMax: u, verificada: false, fuente: f })
      n++
    }
    return n
  },
})

// Tabulador público: solo partidas verificadas por la Secretaría
export const publico = query({
  args: {},
  handler: async (ctx) => {
    const l = await ctx.db.query("infracciones").take(500)
    return l
      .filter((i) => i.verificada !== false)
      .map((i) => ({ _id: i._id, clave: i.clave, articulo: i.articulo, descripcion: i.descripcion, umasMin: i.umasMin, umasMax: i.umasMax }))
  },
})

export const actualizar = mutation({
  args: { clave: v.string(), id: v.id("infracciones"), clave_inf: v.string(), descripcion: v.string(), umasMin: v.number(), umasMax: v.number() },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    if (!a.descripcion.trim() || !(a.umasMin > 0) || a.umasMax < a.umasMin) throw new Error("Datos incompletos")
    await ctx.db.patch(a.id, { clave: a.clave_inf.trim().slice(0, 30), descripcion: a.descripcion.trim().slice(0, 200), umasMin: a.umasMin, umasMax: a.umasMax, verificada: true })
  },
})

export const borrar = mutation({
  args: { clave: v.string(), id: v.id("infracciones") },
  handler: async (ctx, a) => {
    await verificar(ctx, a.clave, true)
    await ctx.db.delete(a.id)
  },
})
